//! Serve web dashboard HTML shell (`GET /`).
//!
//! Upstream parity (A1, #2715 / #2722 / #2723): static embedded page,
//! `Cache-Control: no-store`, provider-id → icon-URL map injected at serve
//! time (sorted, deterministic), refresh interval injected from the serve
//! configuration. The page itself fetches `/dashboard/v1/snapshot` and `/cost`
//! with the user's bearer token and renders grouped provider cards, per-account
//! claude sections, and daily spend bar charts.

/// Render the shell with config-derived values baked in.
pub fn render_shell(refresh_seconds: u32) -> String {
    const TEMPLATE: &str = include_str!("dashboard.html");
    TEMPLATE
        .replace("__PROVIDER_ICON_URLS__", &super::icons::icon_url_map())
        .replace("__REFRESH_SECONDS__", &refresh_seconds.to_string())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn shell_injects_icons_and_refresh_without_leftover_placeholders() {
        let html = render_shell(90);
        assert!(!html.contains("__PROVIDER_ICON_URLS__"));
        assert!(!html.contains("__REFRESH_SECONDS__"));
        assert!(html.contains(r#""codex":"/icons/ProviderIcon-codex.svg""#));
        assert!(html.contains("Math.max(15, 90)"));
        assert!(html.contains("/dashboard/v1/snapshot"));
        assert!(html.contains("/cost"));
    }

    #[test]
    fn shell_is_self_contained() {
        let html = render_shell(60);
        assert!(
            !html.contains("http://") && !html.contains("https://"),
            "no external refs: {}",
            ""
        );
        assert!(html.contains("Content-Security-Policy"));
    }

    #[test]
    fn status_chip_is_conditional_only_2723() {
        let html = render_shell(60);
        assert!(html.contains("statusChip"));
        assert!(
            html.contains("if (!status || !status.level) return \"\""),
            "#2723: chip must be hidden whenever no provider status exists"
        );
    }

    /// The daily chart gate and every per-row value read must agree with the
    /// `/cost` wire key (`totalCost`). The shell is static, so the agreement is
    /// pinned by exact-string assertions on the rendered template.
    #[test]
    fn web_ui_skips_windows_marked_idle() {
        let html = render_shell(60);
        assert!(html.contains("function visibleWindows(windows)"));
        assert!(html.contains("w.idle !== true"));
        assert!(html.contains("visibleWindows(account.windows).forEach"));
        assert!(html.contains("visibleWindows(row.windows).forEach"));
    }

    #[test]
    fn usage_bar_display_uses_one_selected_value_for_label_geometry_and_aria() {
        let html = render_shell(60);
        assert!(html.contains("function windowPercent(w, showUsed)"));
        assert!(html.contains("w.remainingPercent ?? (100 - w.usedPercent)"));
        assert!(html.contains("const pct = windowPercent(w, showUsed)"));
        assert!(html.contains("pct.toFixed(0) + \"% \" + suffix"));
        assert!(html.contains("const width = pct === null ? 0 : pct"));
        assert!(html.contains("aria-valuenow"));
        assert!(html.contains("aria-valuetext"));
        assert!(html.contains("w.usageKnown === false"));
        assert!(html.contains("pct === null ? \"unknown\""));
    }

    #[test]
    fn legacy_snapshots_without_fill_preference_default_to_remaining() {
        let html = render_shell(60);
        assert!(html.contains(
            "Boolean(state.snapshot && state.snapshot.host && state.snapshot.host.usageBarsShowUsed)"
        ));
        assert!(html.contains("const suffix = showUsed ? \"used\" : \"left\""));
        assert!(html.contains("function windowPercent(w, showUsed)"));
    }

    #[test]
    fn usage_display_control_offers_server_used_remaining() {
        let html = render_shell(60);
        assert!(html.contains(r#"<select id="usage-display">"#));
        assert!(html.contains(r#"<option value="server">Follow server</option>"#));
        assert!(html.contains(r#"<option value="used">Used</option>"#));
        assert!(html.contains(r#"<option value="remaining">Remaining</option>"#));
        assert!(html.contains(r#"<label class="display-preference" for="usage-display">"#));
    }

    #[test]
    fn usage_display_preference_is_stored_defensively() {
        let html = render_shell(60);
        assert!(html.contains(r#"const USAGE_DISPLAY_KEY = "codexbar.dashboard.usageDisplay""#));
        // Only `used` and `remaining` are accepted; everything else, including a
        // throwing `getItem`, falls back to following the server.
        assert!(
            html.contains(
                r#"return value === "used" || value === "remaining" ? value : "server";"#
            )
        );
        assert!(html.contains("localStorage.removeItem(USAGE_DISPLAY_KEY)"));
        assert!(html.contains("localStorage.setItem(USAGE_DISPLAY_KEY, state.usageDisplay)"));
        assert!(html.contains("the selection still applies to this page without storage"));
    }

    #[test]
    fn usage_display_change_rerenders_cached_snapshot_without_refetch() {
        // CI checks out with CRLF; the boundary search below assumes LF.
        let html = render_shell(60).replace("\r\n", "\n");
        let start = html
            .find("function changeUsageDisplay()")
            .expect("change handler");
        let end = html[start..].find("\n}\n").expect("handler end") + start;
        let handler = &html[start..end];
        assert!(handler.contains("renderProviders();"));
        for forbidden in [
            "refresh(",
            "fetch(",
            "showError(",
            "sessionStorage",
            "state.token",
        ] {
            assert!(
                !handler.contains(forbidden),
                "usage display change must not touch {forbidden}"
            );
        }
        assert!(html.contains("els.usageDisplay.addEventListener(\"change\", changeUsageDisplay)"));
    }

    #[test]
    fn usage_display_override_wins_over_server_preference() {
        let html = render_shell(60);
        assert!(html.contains("const showUsed = showUsedBars();"));
        assert!(html.contains(
            r#"if (state.usageDisplay !== "server") return state.usageDisplay === "used";"#
        ));
        assert!(html.contains(
            "Boolean(state.snapshot && state.snapshot.host && state.snapshot.host.usageBarsShowUsed)"
        ));
    }

    #[test]
    fn severity_follows_consumption_not_displayed_value() {
        let html = render_shell(60);
        assert!(html.contains("function windowBarClass(w)"));
        assert!(html.contains("return Number.isFinite(used) ? pctClass(used) : \"bar\";"));
        assert!(html.contains("windowBarClass(w)"));
        assert!(
            !html.contains("pctClass(pct)"),
            "severity must not be derived from the displayed (possibly remaining) value"
        );
    }

    #[test]
    fn snapshot_is_cached_before_rows_render() {
        // CI checks out with CRLF; the multi-line search below assumes LF.
        let html = render_shell(60).replace("\r\n", "\n");
        let assign = html.find("state.snapshot = snapshot;").expect("assignment");
        let render = html
            .find("renderProviders();\n  const host")
            .expect("render call");
        assert!(
            assign < render,
            "rows must read the new snapshot's host preference"
        );
    }

    #[test]
    fn daily_chart_gate_reads_upstream_total_cost_key() {
        let html = render_shell(60);
        // Gate: render only when some row has a positive totalCost.
        assert!(
            html.contains("daily.some(v => (v.totalCost || 0) > 0)"),
            "chart gate must gate on the upstream totalCost key"
        );
        // Every per-row value read uses the upstream key — no stale costUSD.
        assert!(
            !html.contains("costUSD"),
            "stale costUSD reads must not survive the totalCost rename"
        );
        assert!(
            !html.contains("daily.some(v => v > 0)"),
            "bare value gate must be replaced with the totalCost key gate"
        );
    }

    #[test]
    fn daily_chart_behavior_positive_zero_empty() {
        let html = render_shell(60);
        // The wire key the shell reads matches the data.rs `daily_json` key.
        assert!(html.contains("d.totalCost"));
        // Zero rows are rendered with the `.zero` class (kept, not hidden by the
        // gate), and the gate hides an all-zero / empty daily series entirely.
        assert!(html.contains("\" zero\""));
        // Mirror the JS gate predicate in Rust over wire-shaped rows to lock
        // the positive / zero / empty behavior the chart depends on.
        let gate = |rows: &[serde_json::Value]| {
            rows.iter()
                .any(|v| v["totalCost"].as_f64().unwrap_or(0.0) > 0.0)
        };
        assert!(gate(&[
            serde_json::json!({"date":"2026-08-08","totalCost":4.25})
        ]));
        assert!(!gate(&[
            serde_json::json!({"date":"2026-08-07","totalCost":0.0})
        ]));
        assert!(!gate(&[]));
    }
}
