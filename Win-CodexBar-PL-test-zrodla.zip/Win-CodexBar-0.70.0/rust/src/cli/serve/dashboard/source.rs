//! Production dashboard snapshot producer: collects provider usage (bounded,
//! concurrent), local cost-scan data (off-runtime), and Claude token-account
//! rows, then projects them through the pure [`build_snapshot`] mapping.
//!
//! F9/#2717 parity notes (0.48.0): each provider fetch is individually bounded
//! so one slow provider cannot bar the snapshot; a timed-out/failed provider
//! becomes an error ROW, the build still completes, and every waiter receives
//! the finished (late) result via the coordinator — never a discarded build.

use std::collections::{BTreeSet, HashMap};
use std::pin::Pin;
use std::time::Duration;

use chrono::Utc;

use crate::cli::fetch_context::populate_api_region_from_settings;
use crate::core::{CostScanOptions, FetchContext, ProviderId, SourceMode, instantiate_provider};
use crate::cost_scanner::{self, CostScanner};
use crate::settings::Settings;
use crate::spend_contract::build_local_spend_contract_from_summary;

use crate::cli::serve::collection::{
    AccountFetchEnvelope, ClaudeAccountsInput, ProviderFetchEnvelope, RawCostPayload,
    SnapshotCollection,
};
use crate::cli::serve::dashboard::coordinator::{BoxSnapshotArtifactsFuture, SnapshotArtifacts};
use crate::cli::serve::metrics::MetricsSnapshot;

use super::snapshot::{DashboardIdentity, SnapshotInput, SnapshotPayload, build_snapshot};

pub type BoxSnapshotFuture = Pin<Box<dyn Future<Output = Result<SnapshotPayload, String>> + Send>>;

/// Hard bound per provider fetch inside a dashboard build. Existing serve
/// `web_timeout` is 60 s; builds add a 75 s outer envelope (provider-internal
/// bounds stay authoritative, matching upstream's 0.8x-below-the-deadline rule
/// of thumb in spirit: anything genuinely stuck becomes an error row, and the
/// snapshot still completes).
const PROVIDER_FETCH_TIMEOUT: Duration = Duration::from_secs(75);
/// Same bound for one Claude account fetch.
const ACCOUNT_FETCH_TIMEOUT: Duration = Duration::from_secs(75);

/// Collects the stable dashboard-v1 payload independently of its transport
/// (upstream `DashboardSnapshotProducer.live` analog): `codexbar serve` wraps
/// it in the authenticated + cached route, `codexbar dashboard` runs it once.
#[derive(Clone, Debug)]
pub struct SnapshotProducer {
    pub refresh_seconds: u32,
    pub identity: Option<DashboardIdentity>,
    pub version: String,
    /// Outer per-provider fetch envelope; `None` relies on provider-internal
    /// `web_timeout` alone (`--timeout 0` in the dashboard command).
    pub fetch_timeout: Option<Duration>,
}

impl SnapshotProducer {
    pub fn new(refresh_seconds: u32, identity: Option<DashboardIdentity>) -> Self {
        Self {
            refresh_seconds,
            identity,
            version: env!("CARGO_PKG_VERSION").to_string(),
            fetch_timeout: Some(PROVIDER_FETCH_TIMEOUT),
        }
    }

    pub fn with_fetch_timeout(mut self, timeout: Option<Duration>) -> Self {
        self.fetch_timeout = timeout;
        self
    }

    pub fn collect(&self) -> BoxSnapshotFuture {
        let this = self.clone();
        Box::pin(async move { Ok(this.collect_artifacts_inner().await?.dashboard) })
    }

    pub(crate) fn collect_artifacts(&self) -> BoxSnapshotArtifactsFuture<MetricsSnapshot> {
        let this = self.clone();
        Box::pin(async move { this.collect_artifacts_inner().await })
    }

    async fn collect_artifacts_inner(&self) -> Result<SnapshotArtifacts<MetricsSnapshot>, String> {
        let settings = Settings::load();
        // Resolve identity: explicit --identity flag wins; otherwise follow
        // the app's hide_personal_info setting (upstream 0.50.1 #2960).
        let identity = self.identity.unwrap_or(if settings.hide_personal_info {
            DashboardIdentity::Redacted
        } else {
            DashboardIdentity::Full
        });
        let provider_ids: Vec<ProviderId> = settings.get_enabled_provider_ids();

        // Concurrent, individually bounded provider fetches; order restored by index.
        let mut set = tokio::task::JoinSet::new();
        for (index, provider_id) in provider_ids.iter().enumerate() {
            let provider_id = *provider_id;
            let fetch_timeout = self.fetch_timeout;
            let mut ctx = provider_fetch_context();
            populate_api_region_from_settings(provider_id, &settings, &mut ctx);
            set.spawn(async move {
                (
                    index,
                    fetch_provider_envelope(provider_id, ctx, fetch_timeout).await,
                )
            });
        }
        let mut indexed = Vec::with_capacity(provider_ids.len());
        while let Some(joined) = set.join_next().await {
            match joined {
                Ok(item) => indexed.push(item),
                Err(join_error) => {
                    return Err(format!("dashboard build task failed: {join_error}"));
                }
            }
        }
        indexed.sort_by_key(|(index, _)| *index);
        let providers: Vec<ProviderFetchEnvelope> =
            indexed.into_iter().map(|(_, envelope)| envelope).collect();

        let costs = collect_costs(provider_ids.contains(&ProviderId::Pi)).await;
        let claude_accounts =
            collect_claude_accounts(provider_ids.contains(&ProviderId::Claude), &settings).await;

        let order: Vec<String> = provider_ids
            .iter()
            .map(|id| id.cli_name().to_string())
            .collect();
        let enabled: BTreeSet<String> = order.iter().cloned().collect();
        let collection = SnapshotCollection {
            providers,
            costs,
            claude_accounts,
            generated_at: Utc::now(),
            refresh_seconds: self.refresh_seconds,
            order,
            enabled,
        };
        let metrics = MetricsSnapshot::from_collection(&collection);
        Ok(SnapshotArtifacts {
            dashboard: build_snapshot(&SnapshotInput {
                collection,
                identity,
                version: Some(self.version.clone()),
                usage_bars_show_used: Some(settings.show_as_used),
            }),
            sidecar: Some(metrics),
        })
    }
}

/// Fetch one provider with a hard outer bound; the error row carries the
/// failure instead of failing the whole snapshot (F9 semantics).
async fn fetch_provider_envelope(
    provider_id: ProviderId,
    ctx: FetchContext,
    fetch_timeout: Option<Duration>,
) -> ProviderFetchEnvelope {
    let provider = instantiate_provider(provider_id);
    let metadata = provider.metadata();

    let fetch = bounded_fetch(provider_id, ctx, None, fetch_timeout).await;
    ProviderFetchEnvelope {
        id: provider_id.cli_name().to_string(),
        display_name: metadata.display_name.to_string(),
        session_label: metadata.session_label.to_string(),
        weekly_label: metadata.weekly_label.to_string(),
        fetch,
    }
}

fn provider_fetch_context() -> FetchContext {
    FetchContext {
        source_mode: SourceMode::Auto,
        include_credits: true,
        web_timeout: 60,
        verbose: false,
        manual_cookie_header: None,
        manual_cookie_missing: false,
        api_key: None,
        token_account_kind: None,
        token_account_isolated: false,
        workspace_id: None,
        seat_credit_entitlement: None,
        api_region: None,
        gateway_url: None,
        auto_prefer_web: false,
        browser_cookie_import: false,
        requires_optional_usage_completeness: false,
        optional_details_enabled: false,
    }
}

async fn bounded_fetch(
    provider_id: ProviderId,
    ctx: FetchContext,
    label: Option<&str>,
    timeout_budget: Option<Duration>,
) -> Result<crate::core::ProviderFetchResult, String> {
    let provider = instantiate_provider(provider_id);
    let Some(timeout_budget) = timeout_budget else {
        return provider
            .fetch_usage(&ctx)
            .await
            .map_err(|error| match label {
                Some(label) => format!("{label}: {error}"),
                None => error.to_string(),
            });
    };
    let secs = timeout_budget.as_secs();
    match tokio::time::timeout(timeout_budget, provider.fetch_usage(&ctx)).await {
        Ok(Ok(result)) => Ok(result),
        Ok(Err(error)) => Err(match label {
            Some(label) => format!("{label}: {error}"),
            None => error.to_string(),
        }),
        Err(_) => Err(match label {
            Some(label) => format!("{label}: fetch timed out after {secs}s"),
            None => format!("fetch timed out after {secs}s"),
        }),
    }
}

/// Local cost data for the scanned providers, computed off the async
/// runtime so a large corpus cannot stall dashboard builds.
async fn collect_costs(pi_selected: bool) -> HashMap<String, RawCostPayload> {
    let result = tokio::task::spawn_blocking(move || {
        let mut scan_options = CostScanOptions::app_driven();
        scan_options.include_pi_sessions = !pi_selected;
        let scanner = CostScanner::new(30).with_options(scan_options);
        let codex = scanner.scan_codex_with_cancel(None);
        let claude = scanner.scan_claude_with_cancel_and_pi_sessions(None, !pi_selected);
        let pi = scanner.scan_pi_with_cancel(None);
        let pi_contract =
            build_local_spend_contract_from_summary("pi", 30, false, false, false, pi);
        let today = crate::cost_reporting_period::cost_bucket_zone()
            .date(Utc::now())
            .format("%Y-%m-%d")
            .to_string();
        let today_of = |provider: &str| {
            cost_scanner::get_daily_cost_history(provider, 30)
                .into_iter()
                .find(|(day, _)| day == &today)
                .and_then(|(_, cost)| cost)
        };
        let mut costs = HashMap::new();
        costs.insert(
            "codex".to_string(),
            RawCostPayload {
                today_usd: today_of("codex"),
                last_30_days_usd: Some(codex.total_cost_usd),
            },
        );
        costs.insert(
            "claude".to_string(),
            RawCostPayload {
                today_usd: today_of("claude"),
                last_30_days_usd: Some(claude.total_cost_usd),
            },
        );
        costs.insert(
            "pi".to_string(),
            RawCostPayload {
                today_usd: today_of("pi"),
                last_30_days_usd: pi_contract.known_cost_usd,
            },
        );
        costs
    })
    .await;
    match result {
        Ok(costs) => costs,
        Err(join_error) => {
            tracing::warn!(
                ?join_error,
                "dashboard cost scan task failed; continuing without costs"
            );
            HashMap::new()
        }
    }
}

/// Claude token-account rows (upstream "claude-swap" analog): per-account
/// cookie-override fetches, active flag from the store, errors as rows.
async fn collect_claude_accounts(
    claude_enabled: bool,
    settings: &Settings,
) -> Option<ClaudeAccountsInput> {
    if !claude_enabled {
        return None;
    }
    let data = match crate::core::TokenAccountStore::new().load_provider(ProviderId::Claude) {
        Ok(data) => data,
        Err(error) => {
            return Some(ClaudeAccountsInput {
                accounts: Err(format!("claude token accounts unavailable: {error}")),
            });
        }
    };
    let active_index = data.active_account().map(|active| active.id);
    let mut set = tokio::task::JoinSet::new();
    for (index, account) in data.accounts.iter().cloned().enumerate() {
        let header = crate::core::TokenAccountSupport::normalized_cookie_header(
            ProviderId::Claude,
            &account.token,
        );
        let mut ctx = FetchContext {
            source_mode: SourceMode::Auto,
            include_credits: true,
            web_timeout: 60,
            verbose: false,
            manual_cookie_header: Some(header),
            manual_cookie_missing: false,
            api_key: None,
            token_account_kind: None,
            token_account_isolated: false,
            workspace_id: None,
            seat_credit_entitlement: None,
            api_region: None,
            gateway_url: None,
            auto_prefer_web: false,
            browser_cookie_import: false,
            requires_optional_usage_completeness: false,
            optional_details_enabled: false,
        };
        populate_api_region_from_settings(ProviderId::Claude, settings, &mut ctx);
        set.spawn(async move {
            let fetch = bounded_fetch(
                ProviderId::Claude,
                ctx,
                Some(&account.label),
                Some(ACCOUNT_FETCH_TIMEOUT),
            )
            .await;
            (
                index,
                AccountFetchEnvelope {
                    id: account.id.to_string(),
                    label: account.label.clone(),
                    active: active_index == Some(account.id),
                    fetch,
                },
            )
        });
    }
    let mut indexed = Vec::new();
    while let Some(joined) = set.join_next().await {
        if let Ok(item) = joined {
            indexed.push(item);
        }
    }
    indexed.sort_by_key(|(index, _)| *index);
    let accounts: Vec<AccountFetchEnvelope> = indexed.into_iter().map(|(_, row)| row).collect();
    if accounts.is_empty() {
        // No accounts: absent section (same as upstream when the adapter is off).
        return None;
    }
    Some(ClaudeAccountsInput {
        accounts: Ok(accounts),
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn producer_defaults_to_redacted_identity() {
        let producer = SnapshotProducer::new(60, Some(DashboardIdentity::Redacted));
        assert_eq!(producer.identity, Some(DashboardIdentity::Redacted));
        assert_eq!(producer.refresh_seconds, 60);
        assert!(!producer.version.is_empty());
    }

    #[test]
    fn producer_none_identity_follows_settings() {
        let producer = SnapshotProducer::new(60, None);
        assert_eq!(producer.identity, None);
        assert_eq!(producer.refresh_seconds, 60);
    }
}
