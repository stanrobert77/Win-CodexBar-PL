//! Provider trait - defines the interface all providers must implement

use async_trait::async_trait;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use thiserror::Error;

use super::ProviderFetchResult;
use super::last_good_owner::LastGoodOwner;
use super::provider_state::ProviderStateKind;

/// Unique identifier for a provider
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum ProviderId {
    Codex,
    Claude,
    Pi,
    Cursor,
    Factory,
    Gemini,
    Antigravity,
    Copilot,
    Zai,
    MiniMax,
    Kiro,
    VertexAI,
    Augment,
    OpenCode,
    Kimi,
    KimiK2,
    Amp,
    Warp,
    Ollama,
    AzureOpenAI,
    T3Chat,
    OpenRouter,
    JetBrains,
    Alibaba,
    AlibabaTokenPlan,
    NanoGPT,
    Infini,
    Perplexity,
    Abacus,
    Mistral,
    OpenCodeGo,
    Kilo,
    Bedrock,
    Codebuff,
    CodeRabbit,
    DeepSeek,
    DeepInfra,
    AiAnd,
    Windsurf,
    Manus,
    MiMo,
    Doubao,
    CommandCode,
    StepFun,
    Venice,
    OpenAIApi,
    Grok,
    ElevenLabs,
    Deepgram,
    Groq,
    HuggingFace,
    Helmcode,
    V0,
    TypeSafe,
    LLMProxy,
    Chutes,
    LiteLLM,
    Poe,
    Devin,
    Zed,
    CrossModel,
    Qoder,
    CodeBuddy,
    Sakana,
    Sub2Api,
    Wayfinder,
    ZenMux,
    ClinePass,
    LongCat,
    Neuralwatt,
    ZoomMate,
    QwenCloud,
    Notion,
    Xai,
    Fireworks,
    AtlasCloud,
    #[serde(alias = "metaspark")]
    Meta,
    Muse,
    Replicate,
    Nous,
    Hyper,
    GitKraken,
    Bifrost,
    Aixy,
    LLMMan,
    DevPass,
    XKiro,
    Raycast,
    Vercel,
}

impl ProviderId {
    /// Get all provider IDs
    pub fn all() -> &'static [ProviderId] {
        &[
            ProviderId::Codex,
            ProviderId::Claude,
            ProviderId::Pi,
            ProviderId::Cursor,
            ProviderId::Factory,
            ProviderId::Gemini,
            ProviderId::Antigravity,
            ProviderId::Copilot,
            ProviderId::Zai,
            ProviderId::MiniMax,
            ProviderId::Kiro,
            ProviderId::VertexAI,
            ProviderId::Augment,
            ProviderId::OpenCode,
            ProviderId::Kimi,
            ProviderId::KimiK2,
            ProviderId::Amp,
            ProviderId::Warp,
            ProviderId::Ollama,
            ProviderId::AzureOpenAI,
            ProviderId::T3Chat,
            ProviderId::OpenRouter,
            ProviderId::JetBrains,
            ProviderId::Alibaba,
            ProviderId::AlibabaTokenPlan,
            ProviderId::NanoGPT,
            ProviderId::Infini,
            ProviderId::Perplexity,
            ProviderId::Abacus,
            ProviderId::Mistral,
            ProviderId::OpenCodeGo,
            ProviderId::Kilo,
            ProviderId::Bedrock,
            ProviderId::Codebuff,
            ProviderId::CodeRabbit,
            ProviderId::DeepSeek,
            ProviderId::DeepInfra,
            ProviderId::AiAnd,
            ProviderId::Windsurf,
            ProviderId::Manus,
            ProviderId::MiMo,
            ProviderId::Doubao,
            ProviderId::CommandCode,
            ProviderId::StepFun,
            ProviderId::Venice,
            ProviderId::OpenAIApi,
            ProviderId::Grok,
            ProviderId::ElevenLabs,
            ProviderId::Deepgram,
            ProviderId::Groq,
            ProviderId::HuggingFace,
            ProviderId::Helmcode,
            ProviderId::V0,
            ProviderId::TypeSafe,
            ProviderId::LLMProxy,
            ProviderId::Chutes,
            ProviderId::LiteLLM,
            ProviderId::Poe,
            ProviderId::Devin,
            ProviderId::Zed,
            ProviderId::CrossModel,
            ProviderId::Qoder,
            ProviderId::CodeBuddy,
            ProviderId::Sakana,
            ProviderId::Sub2Api,
            ProviderId::Wayfinder,
            ProviderId::ZenMux,
            ProviderId::ClinePass,
            ProviderId::LongCat,
            ProviderId::Neuralwatt,
            ProviderId::ZoomMate,
            ProviderId::QwenCloud,
            ProviderId::Notion,
            ProviderId::Xai,
            ProviderId::Fireworks,
            ProviderId::AtlasCloud,
            ProviderId::Meta,
            ProviderId::Muse,
            ProviderId::Replicate,
            ProviderId::Nous,
            ProviderId::Hyper,
            ProviderId::GitKraken,
            ProviderId::Bifrost,
            ProviderId::Aixy,
            ProviderId::LLMMan,
            ProviderId::DevPass,
            ProviderId::XKiro,
            ProviderId::Raycast,
            ProviderId::Vercel,
        ]
    }

    /// Get the CLI name for this provider
    pub fn cli_name(&self) -> &'static str {
        match self {
            ProviderId::Codex => "codex",
            ProviderId::Claude => "claude",
            ProviderId::Pi => "pi",
            ProviderId::Cursor => "cursor",
            ProviderId::Factory => "factory",
            ProviderId::Gemini => "gemini",
            ProviderId::Antigravity => "antigravity",
            ProviderId::Copilot => "copilot",
            ProviderId::Zai => "zai",
            ProviderId::MiniMax => "minimax",
            ProviderId::Kiro => "kiro",
            ProviderId::VertexAI => "vertexai",
            ProviderId::Augment => "augment",
            ProviderId::OpenCode => "opencode",
            ProviderId::Kimi => "kimi",
            ProviderId::KimiK2 => "kimik2",
            ProviderId::Amp => "amp",
            ProviderId::Warp => "warp",
            ProviderId::Ollama => "ollama",
            ProviderId::AzureOpenAI => "azureopenai",
            ProviderId::T3Chat => "t3chat",
            ProviderId::OpenRouter => "openrouter",
            ProviderId::JetBrains => "jetbrains",
            ProviderId::Alibaba => "alibaba",
            ProviderId::AlibabaTokenPlan => "alibabatokenplan",
            ProviderId::NanoGPT => "nanogpt",
            ProviderId::Infini => "infini",
            ProviderId::Perplexity => "perplexity",
            ProviderId::Abacus => "abacus",
            ProviderId::Mistral => "mistral",
            ProviderId::OpenCodeGo => "opencodego",
            ProviderId::Kilo => "kilo",
            ProviderId::Bedrock => "bedrock",
            ProviderId::Codebuff => "codebuff",
            ProviderId::CodeRabbit => "coderabbit",
            ProviderId::DeepSeek => "deepseek",
            ProviderId::DeepInfra => "deepinfra",
            ProviderId::Fireworks => "fireworks",
            ProviderId::Meta => "meta",
            ProviderId::Muse => "muse",
            ProviderId::Nous => "nous",
            ProviderId::Hyper => "hyper",
            ProviderId::GitKraken => "gitkraken",
            ProviderId::Bifrost => "bifrost",
            ProviderId::Aixy => "aixy",
            ProviderId::LLMMan => "llmman",
            ProviderId::DevPass => "devpass",
            ProviderId::XKiro => "xkiro",
            ProviderId::Raycast => "raycast",
            ProviderId::Vercel => "vercel",
            ProviderId::AiAnd => "aiand",
            ProviderId::Windsurf => "windsurf",
            ProviderId::Manus => "manus",
            ProviderId::MiMo => "mimo",
            ProviderId::Doubao => "doubao",
            ProviderId::CommandCode => "commandcode",
            ProviderId::StepFun => "stepfun",
            ProviderId::Venice => "venice",
            ProviderId::OpenAIApi => "openaiapi",
            ProviderId::Grok => "grok",
            ProviderId::ElevenLabs => "elevenlabs",
            ProviderId::Deepgram => "deepgram",
            ProviderId::Groq => "groq",
            ProviderId::HuggingFace => "huggingface",
            ProviderId::Helmcode => "helmcode",
            ProviderId::V0 => "v0",
            ProviderId::TypeSafe => "typesafe",
            ProviderId::LLMProxy => "llmproxy",
            ProviderId::Chutes => "chutes",
            ProviderId::LiteLLM => "litellm",
            ProviderId::Poe => "poe",
            ProviderId::Devin => "devin",
            ProviderId::Zed => "zed",
            ProviderId::CrossModel => "crossmodel",
            ProviderId::Qoder => "qoder",
            ProviderId::CodeBuddy => "codebuddy",
            ProviderId::Sakana => "sakana",
            ProviderId::Sub2Api => "sub2api",
            ProviderId::Wayfinder => "wayfinder",
            ProviderId::ZenMux => "zenmux",
            ProviderId::ClinePass => "clinepass",
            ProviderId::LongCat => "longcat",
            ProviderId::Neuralwatt => "neuralwatt",
            ProviderId::ZoomMate => "zoommate",
            ProviderId::QwenCloud => "qwen-cloud",
            ProviderId::Notion => "notion",
            ProviderId::Xai => "xai",
            ProviderId::Replicate => "replicate",
            ProviderId::AtlasCloud => "atlascloud",
        }
    }

    /// Get the display name for this provider
    pub fn display_name(&self) -> &'static str {
        match self {
            ProviderId::Codex => "Codex",
            ProviderId::Claude => "Claude",
            ProviderId::Pi => "Pi",
            ProviderId::Cursor => "Cursor",
            ProviderId::Factory => "Factory",
            ProviderId::Gemini => "Gemini",
            ProviderId::Antigravity => "Antigravity",
            ProviderId::Copilot => "Copilot",
            ProviderId::Zai => "z.ai",
            ProviderId::MiniMax => "MiniMax",
            ProviderId::Kiro => "Kiro",
            ProviderId::VertexAI => "Vertex AI",
            ProviderId::Augment => "Augment",
            ProviderId::OpenCode => "OpenCode",
            ProviderId::Kimi => "Kimi",
            // Soft-removed (upstream #2254); still resolvable via CLI for legacy configs.
            ProviderId::KimiK2 => "Kimi K2 (removed)",
            ProviderId::Amp => "Amp",
            ProviderId::Warp => "Warp",
            ProviderId::Ollama => "Ollama",
            ProviderId::AzureOpenAI => "Azure OpenAI",
            ProviderId::T3Chat => "T3 Chat",
            ProviderId::OpenRouter => "OpenRouter",
            ProviderId::JetBrains => "JetBrains AI",
            ProviderId::Alibaba => "Alibaba",
            ProviderId::AlibabaTokenPlan => "Alibaba Token Plan",
            ProviderId::NanoGPT => "NanoGPT",
            ProviderId::Infini => "Infini",
            ProviderId::Perplexity => "Perplexity",
            ProviderId::Abacus => "Abacus AI",
            ProviderId::Mistral => "Mistral",
            ProviderId::OpenCodeGo => "OpenCode Go",
            ProviderId::Kilo => "Kilo",
            ProviderId::Bedrock => "AWS Bedrock",
            ProviderId::Codebuff => "Codebuff",
            ProviderId::CodeRabbit => "CodeRabbit",
            ProviderId::DeepSeek => "DeepSeek",
            ProviderId::DeepInfra => "DeepInfra",
            ProviderId::Fireworks => "Fireworks",
            ProviderId::Meta => "Meta",
            ProviderId::Muse => "Muse Code",
            ProviderId::Nous => "Nous Portal",
            ProviderId::Hyper => "Charm Hyper",
            ProviderId::GitKraken => "GitKraken AI",
            ProviderId::Bifrost => "Bifrost",
            ProviderId::Aixy => "Aixy",
            ProviderId::LLMMan => "llmman",
            ProviderId::DevPass => "DevPass",
            ProviderId::XKiro => "xKiro",
            ProviderId::Raycast => "Raycast",
            ProviderId::Vercel => "Vercel AI Gateway",
            ProviderId::AiAnd => "ai&",
            ProviderId::Windsurf => "Windsurf",
            ProviderId::Manus => "Manus",
            ProviderId::MiMo => "Xiaomi MiMo",
            ProviderId::Doubao => "Doubao",
            ProviderId::CommandCode => "Command Code",
            ProviderId::StepFun => "StepFun",
            ProviderId::Venice => "Venice",
            ProviderId::OpenAIApi => "OpenAI API",
            ProviderId::Grok => "Grok",
            ProviderId::ElevenLabs => "ElevenLabs",
            ProviderId::Deepgram => "Deepgram",
            ProviderId::Groq => "Groq",
            ProviderId::HuggingFace => "Hugging Face",
            ProviderId::Helmcode => "Helmcode",
            ProviderId::V0 => "v0",
            ProviderId::TypeSafe => "TypeSafe",
            ProviderId::LLMProxy => "LLM Proxy",
            ProviderId::Chutes => "Chutes",
            ProviderId::LiteLLM => "LiteLLM",
            ProviderId::Poe => "Poe",
            ProviderId::Devin => "Devin",
            ProviderId::Zed => "Zed",
            // Soft-removed (upstream #2254); still resolvable via CLI for legacy configs.
            ProviderId::CrossModel => "CrossModel (removed)",
            ProviderId::Qoder => "Qoder",
            ProviderId::CodeBuddy => "CodeBuddy",
            ProviderId::Sakana => "Sakana AI",
            ProviderId::Sub2Api => "sub2api",
            ProviderId::Wayfinder => "Wayfinder",
            ProviderId::ZenMux => "ZenMux",
            ProviderId::ClinePass => "ClinePass",
            ProviderId::LongCat => "LongCat",
            ProviderId::Neuralwatt => "Neuralwatt",
            ProviderId::ZoomMate => "ZoomMate",
            ProviderId::QwenCloud => "Qwen Cloud",
            ProviderId::Notion => "Notion AI",
            ProviderId::Xai => "xAI",
            ProviderId::Replicate => "Replicate",
            ProviderId::AtlasCloud => "Atlas Cloud",
        }
    }

    /// Get the cookie domain for this provider.
    /// Returns the domain used for cookie extraction, or None if the provider
    /// doesn't use cookies for authentication.
    pub fn cookie_domain(&self) -> Option<&'static str> {
        match self {
            ProviderId::Claude => Some("claude.ai"),
            ProviderId::Cursor => Some("cursor.com"),
            ProviderId::Factory => Some("app.factory.ai"),
            ProviderId::Codex => Some("chatgpt.com"),
            ProviderId::Pi => None,
            ProviderId::Gemini => Some("aistudio.google.com"),
            ProviderId::Kiro => Some("kiro.dev"),
            ProviderId::Kimi => Some("kimi.moonshot.cn"),
            ProviderId::KimiK2 => Some("platform.moonshot.cn"),
            ProviderId::MiniMax => Some("platform.minimax.io"),
            ProviderId::OpenCode => Some("opencode.ai"),
            ProviderId::Augment => Some("app.augmentcode.com"),
            ProviderId::Amp => Some("sourcegraph.com"),
            ProviderId::Antigravity => Some("antigravity.ai"),
            ProviderId::Alibaba => {
                Some(crate::providers::AlibabaRegion::Singapore.primary_cookie_domain())
            }
            ProviderId::AlibabaTokenPlan => Some("bailian.console.aliyun.com"),
            ProviderId::Ollama => Some("ollama.com"),
            ProviderId::T3Chat => Some("t3.chat"),
            ProviderId::Perplexity => Some("perplexity.ai"),
            ProviderId::Abacus => Some("apps.abacus.ai"),
            ProviderId::Mistral => Some("admin.mistral.ai"),
            ProviderId::OpenCodeGo => Some("opencode.ai"),
            ProviderId::Manus => Some("manus.im"),
            ProviderId::MiMo => Some("platform.xiaomimimo.com"),
            ProviderId::CommandCode => Some("commandcode.ai"),
            ProviderId::Grok => Some("grok.com"),
            ProviderId::Venice => Some("venice.ai"),
            ProviderId::Qoder => Some("qoder.com"),
            ProviderId::CodeBuddy => Some("codebuddy.cn"),
            ProviderId::Sakana => Some("console.sakana.ai"),
            ProviderId::LongCat => Some("longcat.chat"),
            ProviderId::Replicate => Some("replicate.com"),
            ProviderId::AtlasCloud => None,
            ProviderId::Raycast => Some("www.raycast.com"),
            // Token-based providers (don't use cookies)
            ProviderId::Copilot => None,
            ProviderId::Zai => None,
            ProviderId::VertexAI => None,
            ProviderId::JetBrains => None,
            ProviderId::Warp => None,
            ProviderId::AzureOpenAI => None,
            ProviderId::OpenRouter => None,
            ProviderId::NanoGPT => None,
            ProviderId::Infini => None,
            ProviderId::Kilo => None,
            ProviderId::Bedrock => None,
            ProviderId::Codebuff => None,
            ProviderId::CodeRabbit => None,
            ProviderId::DeepSeek => None,
            ProviderId::DeepInfra => None,
            ProviderId::Fireworks => None,
            ProviderId::Meta => None,
            ProviderId::Muse => Some("dev.meta.ai"),
            ProviderId::Nous => None,
            ProviderId::Hyper => Some("hyper.charm.land"),
            ProviderId::GitKraken => None,
            ProviderId::Bifrost => None,
            ProviderId::Aixy => None,
            ProviderId::LLMMan => None,
            ProviderId::DevPass => None,
            ProviderId::XKiro => None,
            ProviderId::Vercel => None,
            ProviderId::AiAnd => None,
            ProviderId::Windsurf => None,
            ProviderId::Doubao => None,
            ProviderId::StepFun => None,
            ProviderId::OpenAIApi => None,
            ProviderId::ElevenLabs => None,
            ProviderId::Deepgram => None,
            ProviderId::Groq => None,
            ProviderId::HuggingFace => None,
            ProviderId::Helmcode => Some("helmcode.com"),
            ProviderId::TypeSafe => Some("typesafe.ai"),
            ProviderId::V0 => None,
            ProviderId::LLMProxy => None,
            ProviderId::Chutes => None,
            ProviderId::LiteLLM => None,
            ProviderId::Poe => None,
            ProviderId::Devin => None,
            ProviderId::Zed => Some("zed.dev"),
            ProviderId::CrossModel => None,
            ProviderId::Sub2Api => None,
            ProviderId::Wayfinder => None,
            ProviderId::ZenMux => None,
            ProviderId::ClinePass => None,
            ProviderId::Neuralwatt => None,
            ProviderId::ZoomMate => Some("zoommate.zoom.us"),
            ProviderId::QwenCloud => Some("qwencloud.com"),
            ProviderId::Notion => Some("app.notion.com"),
            ProviderId::Xai => None,
        }
    }

    /// Id of the longer pool that blocks this provider's shorter windows once
    /// exhausted (upstream 0.69.0 #4091). See [`super::BlockedWindows`].
    pub fn blocking_quota_window_id(&self) -> Option<&'static str> {
        match self {
            ProviderId::Kimi => Some(crate::providers::kimi::MONTHLY_WINDOW_ID),
            _ => None,
        }
    }

    /// Parse from CLI name string
    pub fn from_cli_name(name: &str) -> Option<Self> {
        match name.to_lowercase().as_str() {
            "codex" | "openai" => Some(ProviderId::Codex),
            "claude" | "anthropic" => Some(ProviderId::Claude),
            "pi" | "pi-mono" => Some(ProviderId::Pi),
            "cursor" => Some(ProviderId::Cursor),
            "factory" | "droid" => Some(ProviderId::Factory),
            "gemini" | "google" => Some(ProviderId::Gemini),
            "antigravity" | "agy" => Some(ProviderId::Antigravity),
            "copilot" | "github" => Some(ProviderId::Copilot),
            "zai" | "z.ai" => Some(ProviderId::Zai),
            "minimax" => Some(ProviderId::MiniMax),
            "kiro" | "aws" => Some(ProviderId::Kiro),
            "vertexai" | "vertex" | "vertex ai" => Some(ProviderId::VertexAI),
            "augment" => Some(ProviderId::Augment),
            "opencode" => Some(ProviderId::OpenCode),
            "kimi" | "moonshot" => Some(ProviderId::Kimi),
            "kimik2" | "kimi-k2" | "kimi k2" | "k2" | "kimi k2 (removed)" => {
                Some(ProviderId::KimiK2)
            }
            "amp" | "sourcegraph" => Some(ProviderId::Amp),
            "warp" | "warp-ai" | "warp-terminal" => Some(ProviderId::Warp),
            "ollama" => Some(ProviderId::Ollama),
            "azureopenai" | "azure-openai" | "azure openai" => Some(ProviderId::AzureOpenAI),
            "t3chat" | "t3-chat" | "t3 chat" => Some(ProviderId::T3Chat),
            "openrouter" | "or" => Some(ProviderId::OpenRouter),
            "jetbrains" | "jetbrains-ai" | "jetbrains ai" | "intellij" => {
                Some(ProviderId::JetBrains)
            }
            "alibaba" | "tongyi" | "qianwen" => Some(ProviderId::Alibaba),
            "alibabatokenplan" | "alibaba-token-plan" | "alibaba token plan" | "alibaba-token"
            | "bailian-token-plan" => Some(ProviderId::AlibabaTokenPlan),
            "nanogpt" | "nano-gpt" => Some(ProviderId::NanoGPT),
            "infini" | "infini-ai" => Some(ProviderId::Infini),
            "perplexity" | "pplx" => Some(ProviderId::Perplexity),
            "abacus" | "abacus ai" | "abacus-ai" => Some(ProviderId::Abacus),
            "mistral" | "mistral-ai" | "mistral ai" => Some(ProviderId::Mistral),
            "opencodego" | "opencode-go" | "opencode go" => Some(ProviderId::OpenCodeGo),
            "kilo" => Some(ProviderId::Kilo),
            "bedrock" | "aws-bedrock" | "aws bedrock" => Some(ProviderId::Bedrock),
            "codebuff" | "manicode" => Some(ProviderId::Codebuff),
            "coderabbit" | "code-rabbit" | "code rabbit" => Some(ProviderId::CodeRabbit),
            "deepseek" | "deep-seek" | "ds" => Some(ProviderId::DeepSeek),
            "deepinfra" | "deep-infra" | "di" => Some(ProviderId::DeepInfra),
            "fireworks" | "fireworks-ai" | "fw" => Some(ProviderId::Fireworks),
            "muse" | "muse-code" | "muse code" => Some(ProviderId::Muse),
            "nous" | "nous-portal" | "nous portal" | "hermes" => Some(ProviderId::Nous),
            "hyper" | "charm-hyper" | "charm hyper" => Some(ProviderId::Hyper),
            "gitkraken" | "gitkraken-ai" | "gitkraken ai" => Some(ProviderId::GitKraken),
            "bifrost" | "bifrost-gateway" | "bifrost gateway" => Some(ProviderId::Bifrost),
            "aixy" | "aixy-gateway" | "aixy gateway" => Some(ProviderId::Aixy),
            "llmman" => Some(ProviderId::LLMMan),
            "devpass" => Some(ProviderId::DevPass),
            "xkiro" | "x-kiro" => Some(ProviderId::XKiro),
            "vercel" | "vercel-ai-gateway" | "vercel ai gateway" | "ai-gateway" | "ai gateway" => {
                Some(ProviderId::Vercel)
            }
            "meta" | "metaspark" | "meta-spark" | "muse-spark" | "musespark" | "muse spark"
            | "meta muse spark" => Some(ProviderId::Meta),
            "aiand" | "ai&" | "ai-and" | "ai and" => Some(ProviderId::AiAnd),
            "windsurf" | "codeium" => Some(ProviderId::Windsurf),
            "manus" => Some(ProviderId::Manus),
            "mimo" | "xiaomi" | "xiaomimimo" | "xiaomi-mimo" | "xiaomi mimo" => {
                Some(ProviderId::MiMo)
            }
            "doubao" | "ark" | "volcengine" => Some(ProviderId::Doubao),
            "commandcode" | "command-code" | "command code" => Some(ProviderId::CommandCode),
            "stepfun" | "step-fun" | "step fun" => Some(ProviderId::StepFun),
            "venice" => Some(ProviderId::Venice),
            "openaiapi" | "openai-api" | "openai api" | "openai-balance" => {
                Some(ProviderId::OpenAIApi)
            }
            "grok" | "supergrok" | "super-grok" => Some(ProviderId::Grok),
            "xai" | "x.ai" | "x-ai" => Some(ProviderId::Xai),
            "elevenlabs" | "eleven-labs" | "11labs" => Some(ProviderId::ElevenLabs),
            "deepgram" | "dg" => Some(ProviderId::Deepgram),
            "groq" | "groqcloud" | "groq-cloud" | "groq cloud" => Some(ProviderId::Groq),
            "huggingface" | "hugging-face" | "hugging face" | "hf" => Some(ProviderId::HuggingFace),
            "helmcode" | "nan-builders" | "nan builders" => Some(ProviderId::Helmcode),
            "v0" | "v0-dev" | "v0.dev" => Some(ProviderId::V0),
            "typesafe" | "type-safe" | "type safe" => Some(ProviderId::TypeSafe),
            "llmproxy" | "llm-proxy" | "llm proxy" => Some(ProviderId::LLMProxy),
            "chutes" | "chutes-ai" | "chutes ai" => Some(ProviderId::Chutes),
            "litellm" | "lite-llm" | "lite llm" => Some(ProviderId::LiteLLM),
            "poe" => Some(ProviderId::Poe),
            "devin" => Some(ProviderId::Devin),
            "zed" | "zed-ai" => Some(ProviderId::Zed),
            "crossmodel" | "cross-model" | "cross model" | "crossmodel (removed)" => {
                Some(ProviderId::CrossModel)
            }
            "qoder" => Some(ProviderId::Qoder),
            "codebuddy" | "code-buddy" | "codebuddy-cn" | "codebuddycn" | "腾讯codebuddy" => {
                Some(ProviderId::CodeBuddy)
            }
            "sakana" | "sakana-ai" | "sakana ai" => Some(ProviderId::Sakana),
            "sub2api" | "sub-2-api" | "sub 2 api" => Some(ProviderId::Sub2Api),
            "wayfinder" => Some(ProviderId::Wayfinder),
            "zenmux" | "zen-mux" => Some(ProviderId::ZenMux),
            "clinepass" | "cline-pass" | "cline" => Some(ProviderId::ClinePass),
            "longcat" | "long-cat" | "lc" => Some(ProviderId::LongCat),
            "neuralwatt" | "neural-watt" | "nw" | "neural" => Some(ProviderId::Neuralwatt),
            "qwen-cloud" | "qwencloud" | "qwen" | "qwen-token-plan" | "qwen cloud" => {
                Some(ProviderId::QwenCloud)
            }
            "zoommate" | "zoom-mate" | "zoom mate" => Some(ProviderId::ZoomMate),
            "notion" | "notion-ai" | "notionai" | "notion ai" => Some(ProviderId::Notion),
            "replicate" | "r8" => Some(ProviderId::Replicate),
            "atlascloud" | "atlas-cloud" | "atlas cloud" => Some(ProviderId::AtlasCloud),
            "raycast" | "raycast-ai" => Some(ProviderId::Raycast),
            _ => None,
        }
    }

    /// Soft-removed providers (upstream #2254: Kimi K2 + CrossModel).
    ///
    /// Modules and CLI resolution stay so existing configs and `--provider kimik2`
    /// still work. Settings UI hides them unless already enabled in settings.
    pub fn is_deprecated(&self) -> bool {
        matches!(self, ProviderId::KimiK2 | ProviderId::CrossModel)
    }
}

impl std::fmt::Display for ProviderId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.cli_name())
    }
}

/// Data source mode for fetching usage
///
/// Conventions for providers whose transport is not an OAuth flow: they
/// reuse `OAuth` as the persisted token/API lane (an API key, hub token, or
/// other credential), because the source enum is shared with the settings
/// UI. `Auto` may dispatch to that lane as well.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum SourceMode {
    /// Automatically choose the best available source
    #[default]
    Auto,
    /// Use OAuth API; also the token/API lane for non-OAuth providers
    OAuth,
    /// Use web API with browser cookies
    Web,
    /// Use CLI probe
    Cli,
}

impl SourceMode {
    pub fn parse(s: &str) -> Option<Self> {
        match s.to_lowercase().as_str() {
            "auto" => Some(SourceMode::Auto),
            "oauth" => Some(SourceMode::OAuth),
            "web" => Some(SourceMode::Web),
            "cli" => Some(SourceMode::Cli),
            _ => None,
        }
    }
}

/// Metadata about a provider
#[derive(Debug, Clone)]
pub struct ProviderMetadata {
    pub id: ProviderId,
    pub display_name: &'static str,
    pub session_label: &'static str,
    pub weekly_label: &'static str,
    pub supports_opus: bool,
    pub supports_credits: bool,
    pub default_enabled: bool,
    pub is_primary: bool,
    pub dashboard_url: Option<&'static str>,
    pub status_page_url: Option<&'static str>,
    /// Locale key shown for the provider's tertiary metric lane in settings
    /// pickers when the lane carries a semantic identity beyond "Tertiary"
    /// (upstream F5). `None` renders the generic tertiary label.
    pub tertiary_label_key: Option<&'static str>,
}

/// Errors that can occur when fetching provider data
#[derive(Debug, Error)]
pub enum ProviderError {
    #[error("Provider not installed: {0}")]
    NotInstalled(String),

    #[error("Authentication required")]
    AuthRequired,

    #[error("OAuth error: {0}")]
    OAuth(String),

    #[error("Transient OAuth error: {0}")]
    OAuthTransient(String),

    #[error("OAuth session expired: {0}")]
    OAuthExpired(String),

    #[error("OAuth token revoked: {0}")]
    OAuthRevoked(String),

    #[error("Parse error: {0}")]
    Parse(String),

    #[error("Network error: {0}")]
    Network(#[from] reqwest::Error),

    #[error("Timeout")]
    Timeout,

    #[error("Source mode '{0:?}' not supported for this provider")]
    UnsupportedSource(SourceMode),

    #[error("No cookies available for web API")]
    NoCookies,

    /// Usage needs a provider web session that only a browser sign-in can
    /// restore. `sign_in_url` is the page to open; CLI JSON error rows carry
    /// it as `signInUrl` next to `errorKind: "browserSignInRequired"`.
    #[error("{message}")]
    BrowserSignInRequired {
        message: String,
        sign_in_url: String,
    },

    #[error("{0}")]
    Other(String),

    /// A transport failure tagged with the session that produced it, so the
    /// shell can retain a cached snapshot only for the same session. Build it
    /// with [`ProviderError::with_failure_owner`].
    #[error("{source}")]
    OwnedTransport {
        owner: Option<LastGoodOwner>,
        source: Box<ProviderError>,
    },
}

impl ProviderError {
    /// Return true only for transport failures safe for last-good retention.
    pub fn is_transport_failure(&self) -> bool {
        match self {
            ProviderError::Network(error) => matches!(
                classify_reqwest_error(error),
                ReqwestFailureClass::Timeout | ReqwestFailureClass::Connect
            ),
            ProviderError::Timeout => true,
            ProviderError::OwnedTransport { source, .. } => source.is_transport_failure(),
            _ => false,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ReqwestFailureClass {
    Timeout,
    Connect,
    Terminal,
}

fn classify_reqwest_error(error: &reqwest::Error) -> ReqwestFailureClass {
    // A response-body failure can also carry the timeout flag when the peer
    // stalls while the body is being read. It is terminal for the snapshot,
    // because retaining last-good data would hide a truncated response.
    if error.is_body() || error.is_decode() {
        return ReqwestFailureClass::Terminal;
    }
    if error.is_timeout() {
        return ReqwestFailureClass::Timeout;
    }
    if !error.is_connect() {
        return ReqwestFailureClass::Terminal;
    }

    // A connect classification alone is too broad: it also covers protocol
    // and TLS-handshake failures. Retain only a typed transient socket error.
    if has_io_error_kind(error, std::io::ErrorKind::ConnectionRefused) {
        return ReqwestFailureClass::Connect;
    }

    ReqwestFailureClass::Terminal
}

fn has_io_error_kind(error: &reqwest::Error, kind: std::io::ErrorKind) -> bool {
    fn contains_kind(
        source: Option<&(dyn std::error::Error + 'static)>,
        kind: std::io::ErrorKind,
    ) -> bool {
        let Some(current) = source else {
            return false;
        };
        if let Some(io_error) = current.downcast_ref::<std::io::Error>() {
            if io_error.kind() == kind {
                return true;
            }
            let mut nested = io_error.get_ref();
            while let Some(inner) = nested {
                let Some(inner_io) = inner.downcast_ref::<std::io::Error>() else {
                    break;
                };
                if inner_io.kind() == kind {
                    return true;
                }
                nested = inner_io.get_ref();
            }
        }
        contains_kind(std::error::Error::source(current), kind)
    }

    contains_kind(std::error::Error::source(error), kind)
}

/// Context passed to provider fetch operations
#[derive(Debug, Clone)]
pub struct FetchContext {
    /// Source mode to use
    pub source_mode: SourceMode,

    /// Whether to include credits/cost data
    pub include_credits: bool,

    /// Timeout for web operations in seconds
    pub web_timeout: u64,

    /// Whether to enable verbose logging
    pub verbose: bool,

    /// Manual cookie header (for testing)
    pub manual_cookie_header: Option<String>,

    /// The cookie source is manual and no cookie is stored, or (for providers
    /// whose cookie source only scopes the session) cookies are off. The
    /// provider decides what this means; Replicate fails closed instead of
    /// importing a browser account the user did not select, and Charm Hyper
    /// skips its session lane.
    pub manual_cookie_missing: bool,

    /// API key for providers that require authentication
    pub api_key: Option<String>,

    /// Type of the explicitly selected labeled token account, if any.
    pub token_account_kind: Option<super::TokenAccountKind>,

    /// A selected account is an identity boundary: providers must not retry
    /// another ambient credential or account after its credential fails.
    pub token_account_isolated: bool,

    /// Optional provider workspace/project scope from persisted settings.
    pub workspace_id: Option<String>,

    /// Optional Copilot seat AI-credit allowance supplied by the app settings.
    /// The provider keeps the credit counter unknown when this is absent.
    pub seat_credit_entitlement: Option<f64>,

    /// Optional provider API/web region from persisted settings.
    pub api_region: Option<String>,

    /// Optional provider gateway URL, used by local gateway-backed providers.
    pub gateway_url: Option<String>,

    /// When true, Auto mode prefers web before local (token-account scope,
    /// manual cookie source, etc.). Workspace overrides are checked separately.
    pub auto_prefer_web: bool,

    /// The user chose automatic browser cookie import for a provider whose
    /// cookies only enrich its API usage (`Provider::cookies_only_enrich_usage`).
    /// False for the default manual-without-cookie state and for Off, so those
    /// never read a browser.
    pub browser_cookie_import: bool,

    /// Foreground usage reads (`codexbar usage`, `codexbar serve`) set this so
    /// providers join slow optional enrichment with the full optional-item
    /// timeout budget measured from task start; background/UI polls keep the
    /// short join grace instead (upstream 0.48.0
    /// `requiresOptionalUsageCompleteness`, #2583).
    pub requires_optional_usage_completeness: bool,

    /// The user opted in to the requested provider's optional detail breakdown
    /// (LiteLLM model activity, Claude workspace spend). Scoped to the provider
    /// being fetched; false everywhere the setting is not consulted.
    pub optional_details_enabled: bool,
}

impl Default for FetchContext {
    fn default() -> Self {
        Self {
            source_mode: SourceMode::Auto,
            include_credits: true,
            web_timeout: 60,
            verbose: false,
            manual_cookie_header: None,
            manual_cookie_missing: false,
            api_key: None,
            token_account_kind: None,
            token_account_isolated: false,
            workspace_id: None,
            seat_credit_entitlement: None,
            api_region: None,
            gateway_url: None,
            auto_prefer_web: false,
            browser_cookie_import: false,
            requires_optional_usage_completeness: false,
            optional_details_enabled: false,
        }
    }
}

/// How the shell should treat a failed refresh when a prior good snapshot exists.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LastGoodFailurePolicy {
    Replace,
    Preserve,
    PreserveOnce,
    PreserveOnceThenSurface,
}

/// How the shell should treat a manual cookie source with no cookie present.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ManualEmptyCookiePolicy {
    /// Remap to the shell's generic browser-cookie attempt.
    Fallback,
    /// Keep `SourceMode::Web` with no header so the provider fails closed
    /// instead of importing a browser account the user did not select.
    FailClosedWeb,
}

/// Trait that all providers must implement
#[async_trait]
pub trait Provider: Send + Sync {
    /// Get the provider's unique identifier
    fn id(&self) -> ProviderId;

    /// Get provider metadata
    fn metadata(&self) -> &ProviderMetadata;

    /// Fetch usage data from this provider
    async fn fetch_usage(&self, ctx: &FetchContext) -> Result<ProviderFetchResult, ProviderError>;

    /// Get the available source modes for this provider
    fn available_sources(&self) -> Vec<SourceMode> {
        vec![SourceMode::Auto]
    }

    /// Check if OAuth is supported
    fn supports_oauth(&self) -> bool {
        false
    }

    /// Check if web API (cookies) is supported
    fn supports_web(&self) -> bool {
        false
    }

    /// Check if CLI probe is supported
    fn supports_cli(&self) -> bool {
        false
    }

    /// Detect the version of the CLI tool (if applicable)
    fn detect_version(&self) -> Option<String> {
        None
    }

    /// Whether an explicitly selected manual cookie outranks a token-account override.
    fn manual_cookie_precedes_token_account(&self) -> bool {
        false
    }

    /// Whether a selected token account leaves an `Auto` usage source as `Auto`.
    ///
    /// The shell normally maps a token account with an environment override to
    /// the OAuth (API-only) lane. A provider whose `Auto` source adds an
    /// optional extra on top of the API credential, such as the Hugging Face
    /// prepaid wallet, opts in so the account token does not silently drop it.
    /// An explicitly chosen non-Auto usage source still maps to OAuth.
    fn token_account_preserves_auto_source(&self) -> bool {
        false
    }

    /// How the shell treats a manual cookie source with no cookie present.
    ///
    /// `Fallback` lets the shell remap to its generic browser-cookie attempt.
    /// `FailClosedWeb` keeps `SourceMode::Web` without any header, so the
    /// provider fails closed instead of importing a browser account the user
    /// did not select.
    fn manual_empty_cookie_policy(&self) -> ManualEmptyCookiePolicy {
        ManualEmptyCookiePolicy::Fallback
    }

    /// Whether Automatic metric selection should prefer an exhausted quota lane.
    fn automatic_metric_prioritizes_exhausted_window(&self) -> bool {
        true
    }

    /// Whether an explicit (non-Automatic) metric preference whose lane is
    /// unavailable should still fall through to Automatic selection. Providers
    /// with Automatic-only fallback lanes (seat credits) override this to
    /// `false` so an explicit choice is never silently replaced by fallback
    /// progress.
    fn explicit_preference_falls_through_to_automatic(&self) -> bool {
        true
    }

    /// Whether Automatic metric selection is a dead end when the primary lane
    /// is informational and no secondary lane exists. Providers with
    /// Automatic-only fallback lanes (seat credits) or a named extra lane that
    /// can be the only reported quota (Kimi's monthly pool) override this to
    /// `false` so that lane can still fill in.
    fn automatic_metric_missing_core_is_terminal(&self) -> bool {
        true
    }

    /// Whether Automatic metric selection shows the secondary lane whenever
    /// neither core lane is exhausted, instead of the fuller lane. An
    /// exhausted primary or secondary lane still wins, primary first.
    fn automatic_metric_prefers_secondary_window(&self) -> bool {
        false
    }

    /// Id of the extra rate window that holds this provider's monthly plan
    /// allowance. The `MonthlyPlan` menu bar metric selects that window
    /// (upstream 0.70.0 #4072). `None` means the provider offers no Monthly
    /// Plan metric.
    fn monthly_plan_window_id(&self) -> Option<&'static str> {
        None
    }

    /// Label for the primary lane in the menu bar metric picker when the
    /// lane is not a session window (upstream `menuBarLayoutPrimaryLabel`).
    /// `None` keeps the generic session label.
    fn menu_bar_primary_label(&self) -> Option<&'static str> {
        None
    }

    /// Whether cookies only enrich an API-backed result instead of being a
    /// usage source of their own. The shell then keeps the configured usage
    /// source, forwards a manual cookie as-is, and reads a browser only when
    /// the cookie source is Automatic (`FetchContext::browser_cookie_import`);
    /// the default manual state with no cookie never triggers a browser read.
    fn cookies_only_enrich_usage(&self) -> bool {
        false
    }

    /// Whether browser-cookie discovery/recovery is owned by the provider.
    fn owns_browser_cookie_resolution(&self) -> bool {
        false
    }

    /// Whether the web lane is used only when the usage source is explicitly
    /// `web`. A cookie domain otherwise lets the shell turn Auto into Web
    /// (manual cookie present or browser import), which would replace a
    /// provider's default non-web credential.
    fn web_is_opt_in(&self) -> bool {
        false
    }

    /// Whether the cookie source only scopes the browser session the
    /// provider may use, leaving the selected usage source in charge of
    /// routing.
    ///
    /// When true, the shell keeps the usage source for every cookie source:
    /// `off` and a `manual` source without a stored cookie pass no header and
    /// set [`FetchContext::manual_cookie_missing`], so the provider skips the
    /// session and Auto can still use an API key. Otherwise the shell remaps
    /// the source mode from the cookie source.
    fn cookie_source_scopes_session_only(&self) -> bool {
        false
    }

    /// How the shell should treat a failed refresh when a prior good snapshot exists.
    fn last_good_failure_policy(&self, _error: &str) -> LastGoodFailurePolicy {
        LastGoodFailurePolicy::Replace
    }

    /// Whether this provider can safely retain its last good snapshot on a
    /// classified transport failure.
    fn retains_last_good_on_transport_failure(&self) -> bool {
        false
    }

    /// Typed variant used before an error is sanitized for the frontend.
    ///
    /// Providers that need message-based distinctions can keep overriding the
    /// string method. Transport retention is selected by the provider
    /// capability and the typed error classification above.
    fn last_good_failure_policy_for_error(&self, error: &ProviderError) -> LastGoodFailurePolicy {
        if matches!(error, ProviderError::OAuthTransient(_)) {
            return LastGoodFailurePolicy::Preserve;
        }
        if self.retains_last_good_on_transport_failure() && error.is_transport_failure() {
            return LastGoodFailurePolicy::Preserve;
        }
        self.last_good_failure_policy(&error.to_string())
    }

    /// Presentation-safe availability state for a refresh error. The default
    /// maps `ProviderError` variants, treating `NotInstalled` as a missing
    /// credential (most providers raise it for a missing API key or auth
    /// file). Override only when a variant carries provider-specific meaning
    /// that differs — e.g. a local language-server probe or CLI/binary
    /// presence check whose "not installed" means the runtime is simply
    /// not running; prefer a message-contains guard when the provider also
    /// raises credential-flavored `NotInstalled` errors.
    fn error_state_kind(&self, error: &ProviderError) -> ProviderStateKind {
        error.state_kind()
    }
}

/// Get the CLI name map for argument parsing
pub fn cli_name_map() -> HashMap<&'static str, ProviderId> {
    let mut map = HashMap::new();
    for id in ProviderId::all() {
        map.insert(id.cli_name(), *id);
    }
    // Add aliases
    map.insert("openai", ProviderId::Codex);
    map.insert("anthropic", ProviderId::Claude);
    map.insert("codebuff", ProviderId::Codebuff);
    map.insert("manicode", ProviderId::Codebuff);
    map.insert("deep-seek", ProviderId::DeepSeek);
    map.insert("ds", ProviderId::DeepSeek);
    map.insert("deep-infra", ProviderId::DeepInfra);
    map.insert("di", ProviderId::DeepInfra);
    map.insert("fireworks-ai", ProviderId::Fireworks);
    map.insert("fw", ProviderId::Fireworks);
    map.insert("muse-code", ProviderId::Muse);
    map.insert("muse code", ProviderId::Muse);
    map.insert("nous-portal", ProviderId::Nous);
    map.insert("nous portal", ProviderId::Nous);
    map.insert("hermes", ProviderId::Nous);
    map.insert("x-kiro", ProviderId::XKiro);
    map.insert("vercel-ai-gateway", ProviderId::Vercel);
    map.insert("vercel ai gateway", ProviderId::Vercel);
    map.insert("ai-gateway", ProviderId::Vercel);
    map.insert("ai gateway", ProviderId::Vercel);
    map.insert("metaspark", ProviderId::Meta);
    map.insert("meta-spark", ProviderId::Meta);
    map.insert("muse-spark", ProviderId::Meta);
    map.insert("musespark", ProviderId::Meta);
    map.insert("muse spark", ProviderId::Meta);
    map.insert("meta muse spark", ProviderId::Meta);
    map.insert("ai&", ProviderId::AiAnd);
    map.insert("ai-and", ProviderId::AiAnd);
    map.insert("codeium", ProviderId::Windsurf);
    map.insert("google", ProviderId::Gemini);
    map.insert("agy", ProviderId::Antigravity);
    map.insert("github", ProviderId::Copilot);
    map.insert("aws", ProviderId::Kiro);
    map.insert("vertex", ProviderId::VertexAI);
    map.insert("sourcegraph", ProviderId::Amp);
    map.insert("warp-ai", ProviderId::Warp);
    map.insert("warp-terminal", ProviderId::Warp);
    map.insert("or", ProviderId::OpenRouter);
    map.insert("aws-bedrock", ProviderId::Bedrock);
    map.insert("aws bedrock", ProviderId::Bedrock);
    map.insert("tongyi", ProviderId::Alibaba);
    map.insert("qianwen", ProviderId::Alibaba);
    map.insert("qwen", ProviderId::QwenCloud);
    map.insert("qwencloud", ProviderId::QwenCloud);
    map.insert("qwen-token-plan", ProviderId::QwenCloud);
    map.insert("infini-ai", ProviderId::Infini);
    map.insert("pplx", ProviderId::Perplexity);
    map.insert("abacus-ai", ProviderId::Abacus);
    map.insert("mistral-ai", ProviderId::Mistral);
    map.insert("opencode-go", ProviderId::OpenCodeGo);
    map.insert("xiaomimimo", ProviderId::MiMo);
    map.insert("xiaomi-mimo", ProviderId::MiMo);
    map.insert("ark", ProviderId::Doubao);
    map.insert("volcengine", ProviderId::Doubao);
    map.insert("command-code", ProviderId::CommandCode);
    map.insert("step-fun", ProviderId::StepFun);
    map.insert("openai-api", ProviderId::OpenAIApi);
    map.insert("openai-balance", ProviderId::OpenAIApi);
    map.insert("xai", ProviderId::Xai);
    map.insert("x.ai", ProviderId::Xai);
    map.insert("supergrok", ProviderId::Grok);
    map.insert("eleven-labs", ProviderId::ElevenLabs);
    map.insert("11labs", ProviderId::ElevenLabs);
    map.insert("dg", ProviderId::Deepgram);
    map.insert("groqcloud", ProviderId::Groq);
    map.insert("groq-cloud", ProviderId::Groq);
    map.insert("hugging-face", ProviderId::HuggingFace);
    map.insert("hf", ProviderId::HuggingFace);
    map.insert("nan-builders", ProviderId::Helmcode);
    map.insert("v0-dev", ProviderId::V0);
    map.insert("type-safe", ProviderId::TypeSafe);
    map.insert("chutes-ai", ProviderId::Chutes);
    map.insert("lite-llm", ProviderId::LiteLLM);
    map.insert("zed-ai", ProviderId::Zed);
    map.insert("llm-proxy", ProviderId::LLMProxy);
    map.insert("cross-model", ProviderId::CrossModel);
    map.insert("sakana-ai", ProviderId::Sakana);
    map.insert("sub-2-api", ProviderId::Sub2Api);
    map.insert("notion-ai", ProviderId::Notion);
    map.insert("notionai", ProviderId::Notion);
    map
}

/// The shipped brand color (hex) for a provider, mirroring the frontend
/// `PROVIDER_ICON_REGISTRY` in `providerIcons.ts` and the `--chart-<id>`
/// tokens in `styles.css` (`providerIcons.test.ts` checks both). Used as the
/// default accent color before any per-provider override (#2972).
///
/// Upstream 0.70.0 audited the palette (#4075, `docs/provider-palette.md`).
/// The 16 accents it adopted are pinned in the tests below; changing one
/// must not materially reduce contrast on white or `#222222`.
pub fn brand_color(id: ProviderId) -> &'static str {
    match id {
        ProviderId::Codex => "#49A3B0",
        ProviderId::Claude => "#CC7C5E",
        ProviderId::Pi => "#7C3AED",
        ProviderId::Cursor => "#F54E00",
        ProviderId::Factory => "#FF6B35",
        ProviderId::Gemini => "#AB87EA",
        ProviderId::Antigravity => "#60BA7E",
        ProviderId::Copilot => "#A855F7",
        ProviderId::Zai => "#E85A6A",
        ProviderId::MiniMax => "#FE603C",
        ProviderId::Kiro => "#9046FF",
        ProviderId::VertexAI => "#4285F4",
        ProviderId::Augment => "#1AA049",
        ProviderId::OpenCode => "#3B82F6",
        ProviderId::Kimi => "#FE603C",
        ProviderId::KimiK2 => "#4C00FF",
        ProviderId::Amp => "#F34E3F",
        ProviderId::Warp => "#6366F1",
        ProviderId::Ollama => "#8B95B0",
        ProviderId::AzureOpenAI => "#0078D4",
        ProviderId::T3Chat => "#8B5CF6",
        ProviderId::OpenRouter => "#6B7280",
        ProviderId::JetBrains => "#FF3399",
        ProviderId::Alibaba => "#FF6A00",
        ProviderId::AlibabaTokenPlan => "#FF6A00",
        ProviderId::NanoGPT => "#687FA1",
        ProviderId::Infini => "#687FA1",
        ProviderId::Perplexity => "#1FB8CD",
        ProviderId::Abacus => "#814EE8",
        ProviderId::Mistral => "#FF5229",
        ProviderId::OpenCodeGo => "#3B82F6",
        ProviderId::Kilo => "#5D87FF",
        ProviderId::Bedrock => "#01A88D",
        ProviderId::Codebuff => "#00FF95",
        ProviderId::CodeRabbit => "#FF5C35",
        ProviderId::DeepSeek => "#4D6BFE",
        ProviderId::DeepInfra => "#2A3275",
        ProviderId::AiAnd => "#E25C2B",
        ProviderId::Windsurf => "#22C55E",
        ProviderId::Manus => "#34322D",
        ProviderId::MiMo => "#FF6900",
        ProviderId::Doubao => "#2563EB",
        ProviderId::CommandCode => "#8C4EDD",
        ProviderId::StepFun => "#999999",
        ProviderId::Venice => "#3C8FDD",
        ProviderId::OpenAIApi => "#10A37F",
        ProviderId::Grok => "#111827",
        ProviderId::ElevenLabs => "#111827",
        ProviderId::Deepgram => "#13EF93",
        ProviderId::Groq => "#F55036",
        ProviderId::HuggingFace => "#FFD21E",
        ProviderId::Helmcode => "#4F46E5",
        ProviderId::V0 => "#111827",
        ProviderId::TypeSafe => "#2563EB",
        ProviderId::LLMProxy => "#4F46E5",
        ProviderId::Chutes => "#FF5C35",
        ProviderId::LiteLLM => "#0EA5E9",
        ProviderId::Poe => "#5D5FEF",
        ProviderId::Devin => "#317CFF",
        ProviderId::Zed => "#084CCF",
        ProviderId::CrossModel => "#C084FC",
        ProviderId::Qoder => "#2563EB",
        ProviderId::CodeBuddy => "#0052D9",
        ProviderId::Sakana => "#0EA5E9",
        ProviderId::Sub2Api => "#14B8A6",
        ProviderId::Wayfinder => "#14B8A6",
        ProviderId::ZenMux => "#6C5CE7",
        ProviderId::ClinePass => "#5487C8",
        ProviderId::LongCat => "#29E154",
        ProviderId::Neuralwatt => "#D55934",
        ProviderId::ZoomMate => "#0B5CFF",
        ProviderId::QwenCloud => "#615CED",
        ProviderId::Notion => "#337EA9",
        ProviderId::Xai => "#8E8E93",
        ProviderId::Fireworks => "#F25B1C",
        ProviderId::Meta => "#0467DF",
        ProviderId::Muse => "#0668E1",
        ProviderId::Replicate => "#000000",
        ProviderId::AtlasCloud => "#5975F5",
        ProviderId::Nous => "#D6A55C",
        ProviderId::Hyper => "#FF60FF",
        ProviderId::GitKraken => "#179287",
        ProviderId::Bifrost => "#33C09E",
        ProviderId::Aixy => "#123650",
        ProviderId::LLMMan => "#6CC5B0",
        ProviderId::DevPass => "#2563EB",
        ProviderId::XKiro => "#52C99B",
        ProviderId::Raycast => "#FF6363",
        // Upstream uses white; a mid neutral keeps contrast on light and dark surfaces.
        ProviderId::Vercel => "#737373",
    }
}

#[cfg(test)]
#[path = "provider_transport_tests.rs"]
mod transport_tests;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_provider_id_all() {
        let all = ProviderId::all();
        assert_eq!(all.len(), 89);
        assert!(all.contains(&ProviderId::Claude));
        assert!(all.contains(&ProviderId::Codex));
        assert!(all.contains(&ProviderId::Pi));
        assert!(all.contains(&ProviderId::Fireworks));
        assert!(all.contains(&ProviderId::Kimi));
        assert!(all.contains(&ProviderId::KimiK2));
        assert!(all.contains(&ProviderId::Amp));
        assert!(all.contains(&ProviderId::AzureOpenAI));
        assert!(all.contains(&ProviderId::T3Chat));
        assert!(all.contains(&ProviderId::JetBrains));
        assert!(all.contains(&ProviderId::AlibabaTokenPlan));
        assert!(all.contains(&ProviderId::NanoGPT));
        assert!(all.contains(&ProviderId::Infini));
        assert!(all.contains(&ProviderId::Bedrock));
        assert!(all.contains(&ProviderId::Codebuff));
        assert!(all.contains(&ProviderId::CodeRabbit));
        assert!(all.contains(&ProviderId::DeepSeek));
        assert!(all.contains(&ProviderId::DeepInfra));
        assert!(all.contains(&ProviderId::AiAnd));
        assert!(all.contains(&ProviderId::Windsurf));
        assert!(all.contains(&ProviderId::Manus));
        assert!(all.contains(&ProviderId::MiMo));
        assert!(all.contains(&ProviderId::Doubao));
        assert!(all.contains(&ProviderId::CommandCode));
        assert!(all.contains(&ProviderId::StepFun));
        assert!(all.contains(&ProviderId::Venice));
        assert!(all.contains(&ProviderId::OpenAIApi));
        assert!(all.contains(&ProviderId::Grok));
        assert!(all.contains(&ProviderId::ElevenLabs));
        assert!(all.contains(&ProviderId::Deepgram));
        assert!(all.contains(&ProviderId::Groq));
        assert!(all.contains(&ProviderId::HuggingFace));
        assert!(all.contains(&ProviderId::Helmcode));
        assert!(all.contains(&ProviderId::V0));
        assert!(all.contains(&ProviderId::TypeSafe));
        assert!(all.contains(&ProviderId::LLMProxy));
        assert!(all.contains(&ProviderId::Chutes));
        assert!(all.contains(&ProviderId::LiteLLM));
        assert!(all.contains(&ProviderId::Poe));
        assert!(all.contains(&ProviderId::Devin));
        assert!(all.contains(&ProviderId::Zed));
        assert!(all.contains(&ProviderId::CrossModel));
        assert!(all.contains(&ProviderId::Qoder));
        assert!(all.contains(&ProviderId::CodeBuddy));
        assert!(all.contains(&ProviderId::Sakana));
        assert!(all.contains(&ProviderId::Sub2Api));
        assert!(all.contains(&ProviderId::Wayfinder));
        assert!(all.contains(&ProviderId::ZenMux));
        assert!(all.contains(&ProviderId::ClinePass));
        assert!(all.contains(&ProviderId::LongCat));
        assert!(all.contains(&ProviderId::Neuralwatt));
        assert!(all.contains(&ProviderId::ZoomMate));
        assert!(all.contains(&ProviderId::QwenCloud));
        assert!(all.contains(&ProviderId::Notion));
        assert!(all.contains(&ProviderId::Xai));
        assert!(all.contains(&ProviderId::Meta));
        assert!(all.contains(&ProviderId::Replicate));
        assert!(all.contains(&ProviderId::Muse));
        assert!(all.contains(&ProviderId::Nous));
        assert!(all.contains(&ProviderId::AtlasCloud));
        assert!(all.contains(&ProviderId::Hyper));
        assert!(all.contains(&ProviderId::GitKraken));
        assert!(all.contains(&ProviderId::Bifrost));
        assert!(all.contains(&ProviderId::Aixy));
        assert!(all.contains(&ProviderId::LLMMan));
        assert!(all.contains(&ProviderId::DevPass));
        assert!(all.contains(&ProviderId::XKiro));
        assert!(all.contains(&ProviderId::Raycast));
        assert!(all.contains(&ProviderId::Vercel));
    }

    #[test]
    fn deprecated_providers_are_kimik2_and_crossmodel() {
        assert!(ProviderId::KimiK2.is_deprecated());
        assert!(ProviderId::CrossModel.is_deprecated());
        assert!(!ProviderId::Kimi.is_deprecated());
        assert!(!ProviderId::AiAnd.is_deprecated());
        assert!(ProviderId::KimiK2.display_name().contains("(removed)"));
        assert!(ProviderId::CrossModel.display_name().contains("(removed)"));
        assert_eq!(
            ProviderId::from_cli_name("kimik2"),
            Some(ProviderId::KimiK2)
        );
        assert_eq!(
            ProviderId::from_cli_name("crossmodel"),
            Some(ProviderId::CrossModel)
        );
    }

    #[test]
    fn aiand_cli_aliases_resolve() {
        assert_eq!(ProviderId::from_cli_name("aiand"), Some(ProviderId::AiAnd));
        assert_eq!(ProviderId::from_cli_name("ai&"), Some(ProviderId::AiAnd));
        assert_eq!(ProviderId::from_cli_name("ai-and"), Some(ProviderId::AiAnd));
        assert_eq!(ProviderId::AiAnd.cli_name(), "aiand");
        assert_eq!(ProviderId::AiAnd.display_name(), "ai&");
    }

    #[test]
    fn test_provider_id_cli_name() {
        assert_eq!(ProviderId::Claude.cli_name(), "claude");
        assert_eq!(ProviderId::Codex.cli_name(), "codex");
        assert_eq!(ProviderId::Factory.cli_name(), "factory");
        assert_eq!(ProviderId::Zai.cli_name(), "zai");
        assert_eq!(ProviderId::HuggingFace.cli_name(), "huggingface");
        assert_eq!(ProviderId::CodeRabbit.cli_name(), "coderabbit");
    }

    #[test]
    fn test_provider_id_display_name() {
        assert_eq!(ProviderId::Claude.display_name(), "Claude");
        assert_eq!(ProviderId::Factory.display_name(), "Factory");
        assert_eq!(ProviderId::Zai.display_name(), "z.ai");
        assert_eq!(ProviderId::HuggingFace.display_name(), "Hugging Face");
        assert_eq!(ProviderId::CodeRabbit.display_name(), "CodeRabbit");
    }

    #[test]
    fn test_provider_id_from_cli_name() {
        assert_eq!(
            ProviderId::from_cli_name("claude"),
            Some(ProviderId::Claude)
        );
        assert_eq!(
            ProviderId::from_cli_name("anthropic"),
            Some(ProviderId::Claude)
        );
        assert_eq!(
            ProviderId::from_cli_name("CLAUDE"),
            Some(ProviderId::Claude)
        );
        assert_eq!(ProviderId::from_cli_name("codex"), Some(ProviderId::Codex));
        assert_eq!(
            ProviderId::from_cli_name("hf"),
            Some(ProviderId::HuggingFace)
        );
        assert_eq!(ProviderId::from_cli_name("openai"), Some(ProviderId::Codex));
        assert_eq!(
            ProviderId::from_cli_name("factory"),
            Some(ProviderId::Factory)
        );
        assert_eq!(
            ProviderId::from_cli_name("agy"),
            Some(ProviderId::Antigravity)
        );
        assert_eq!(ProviderId::from_cli_name("zed"), Some(ProviderId::Zed));
        assert_eq!(ProviderId::from_cli_name("crof"), None);
        assert_eq!(ProviderId::from_cli_name("unknown"), None);
        assert_eq!(
            ProviderId::from_cli_name("code-rabbit"),
            Some(ProviderId::CodeRabbit)
        );
    }

    #[test]
    fn test_provider_id_from_display_name_aliases() {
        for provider_id in ProviderId::all() {
            assert_eq!(
                ProviderId::from_cli_name(provider_id.display_name()),
                Some(*provider_id),
                "display name should round-trip for {}",
                provider_id.display_name()
            );
        }
    }

    #[test]
    fn test_provider_id_display() {
        assert_eq!(format!("{}", ProviderId::Claude), "claude");
        assert_eq!(format!("{}", ProviderId::Codex), "codex");
    }

    #[test]
    fn test_source_mode_from_str() {
        assert_eq!(SourceMode::parse("auto"), Some(SourceMode::Auto));
        assert_eq!(SourceMode::parse("oauth"), Some(SourceMode::OAuth));
        assert_eq!(SourceMode::parse("web"), Some(SourceMode::Web));
        assert_eq!(SourceMode::parse("cli"), Some(SourceMode::Cli));
        assert_eq!(SourceMode::parse("AUTO"), Some(SourceMode::Auto));
        assert_eq!(SourceMode::parse("invalid"), None);
    }

    #[test]
    fn test_fetch_context_default() {
        let ctx = FetchContext::default();
        assert_eq!(ctx.source_mode, SourceMode::Auto);
        assert!(ctx.include_credits);
        assert_eq!(ctx.web_timeout, 60);
        assert!(!ctx.verbose);
        assert!(ctx.manual_cookie_header.is_none());
        assert!(ctx.api_key.is_none());
    }

    #[test]
    fn test_cli_name_map() {
        let map = cli_name_map();
        assert_eq!(map.get("claude"), Some(&ProviderId::Claude));
        assert_eq!(map.get("anthropic"), Some(&ProviderId::Claude));
        assert_eq!(map.get("codex"), Some(&ProviderId::Codex));
        assert_eq!(map.get("openai"), Some(&ProviderId::Codex));
        assert_eq!(map.get("agy"), Some(&ProviderId::Antigravity));
    }

    #[test]
    fn test_provider_id_cookie_domain() {
        // Cookie-based providers
        assert_eq!(ProviderId::Claude.cookie_domain(), Some("claude.ai"));
        assert_eq!(ProviderId::Cursor.cookie_domain(), Some("cursor.com"));
        assert_eq!(ProviderId::Factory.cookie_domain(), Some("app.factory.ai"));
        assert_eq!(ProviderId::Codex.cookie_domain(), Some("chatgpt.com"));
        assert_eq!(
            ProviderId::Gemini.cookie_domain(),
            Some("aistudio.google.com")
        );
        assert_eq!(ProviderId::Kiro.cookie_domain(), Some("kiro.dev"));
        assert_eq!(ProviderId::Zed.cookie_domain(), Some("zed.dev"));
        assert_eq!(ProviderId::Kimi.cookie_domain(), Some("kimi.moonshot.cn"));
        assert_eq!(ProviderId::OpenCode.cookie_domain(), Some("opencode.ai"));
        assert_eq!(ProviderId::Venice.cookie_domain(), Some("venice.ai"));

        // Token-based providers (no cookies)
        assert_eq!(ProviderId::Copilot.cookie_domain(), None);
        assert_eq!(ProviderId::Zai.cookie_domain(), None);
        assert_eq!(ProviderId::VertexAI.cookie_domain(), None);
        assert_eq!(ProviderId::JetBrains.cookie_domain(), None);
        assert_eq!(ProviderId::HuggingFace.cookie_domain(), None);
        assert_eq!(ProviderId::CodeRabbit.cookie_domain(), None);
    }

    #[test]
    fn test_provider_id_alibaba() {
        assert_eq!(ProviderId::Alibaba.cli_name(), "alibaba");
        assert_eq!(ProviderId::Alibaba.display_name(), "Alibaba");
        assert_eq!(
            ProviderId::Alibaba.cookie_domain(),
            Some("modelstudio.console.alibabacloud.com")
        );
        assert_eq!(
            ProviderId::from_cli_name("alibaba"),
            Some(ProviderId::Alibaba)
        );
        assert_eq!(
            ProviderId::from_cli_name("tongyi"),
            Some(ProviderId::Alibaba)
        );
        assert_eq!(
            ProviderId::from_cli_name("qianwen"),
            Some(ProviderId::Alibaba)
        );
    }

    #[test]
    fn test_provider_id_qwen_cloud() {
        assert_eq!(ProviderId::QwenCloud.cli_name(), "qwen-cloud");
        assert_eq!(ProviderId::QwenCloud.display_name(), "Qwen Cloud");
        assert_eq!(ProviderId::QwenCloud.cookie_domain(), Some("qwencloud.com"));
        assert_eq!(
            ProviderId::from_cli_name("qwen-cloud"),
            Some(ProviderId::QwenCloud)
        );
        assert_eq!(
            ProviderId::from_cli_name("qwencloud"),
            Some(ProviderId::QwenCloud)
        );
        assert_eq!(
            ProviderId::from_cli_name("qwen"),
            Some(ProviderId::QwenCloud)
        );
        assert_eq!(
            ProviderId::from_cli_name("qwen-token-plan"),
            Some(ProviderId::QwenCloud)
        );
        assert_eq!(
            ProviderId::from_cli_name("qwen cloud"),
            Some(ProviderId::QwenCloud)
        );
        // Bare "qwen" must not resolve to Alibaba Coding Plan.
        assert_ne!(ProviderId::from_cli_name("qwen"), Some(ProviderId::Alibaba));
    }

    #[test]
    fn test_provider_id_notion() {
        assert_eq!(ProviderId::Notion.cli_name(), "notion");
        assert_eq!(ProviderId::Notion.display_name(), "Notion AI");
        assert_eq!(ProviderId::Notion.cookie_domain(), Some("app.notion.com"));
        assert_eq!(
            ProviderId::from_cli_name("notion"),
            Some(ProviderId::Notion)
        );
        assert_eq!(
            ProviderId::from_cli_name("notion-ai"),
            Some(ProviderId::Notion)
        );
        assert_eq!(
            ProviderId::from_cli_name("notionai"),
            Some(ProviderId::Notion)
        );
        assert_eq!(
            ProviderId::from_cli_name("notion ai"),
            Some(ProviderId::Notion)
        );
    }

    #[test]
    fn test_provider_id_meta() {
        assert_eq!(ProviderId::Meta.cli_name(), "meta");
        assert_eq!(ProviderId::Meta.display_name(), "Meta");
        assert_eq!(ProviderId::Meta.cookie_domain(), None);
        assert_eq!(ProviderId::from_cli_name("meta"), Some(ProviderId::Meta));
        assert_eq!(
            ProviderId::from_cli_name("metaspark"),
            Some(ProviderId::Meta)
        );
        assert_eq!(
            ProviderId::from_cli_name("meta-spark"),
            Some(ProviderId::Meta)
        );
        assert_eq!(ProviderId::from_cli_name("meta"), Some(ProviderId::Meta));
        assert_eq!(
            ProviderId::from_cli_name("muse-spark"),
            Some(ProviderId::Meta)
        );
        assert_eq!(
            ProviderId::from_cli_name("musespark"),
            Some(ProviderId::Meta)
        );
        // Display name round-trips (also covered by the generic alias test).
        assert_eq!(ProviderId::from_cli_name("Meta"), Some(ProviderId::Meta));
        // Backwards-compat aliases still resolve.
        assert_eq!(
            ProviderId::from_cli_name("Meta Muse Spark"),
            Some(ProviderId::Meta)
        );
        assert_eq!(brand_color(ProviderId::Meta), "#0467DF");
    }

    #[test]
    fn test_provider_id_muse() {
        assert_eq!(ProviderId::Muse.cli_name(), "muse");
        assert_eq!(ProviderId::Muse.display_name(), "Muse Code");
        assert_eq!(ProviderId::Muse.cookie_domain(), Some("dev.meta.ai"));
        assert_eq!(ProviderId::from_cli_name("muse"), Some(ProviderId::Muse));
        assert_eq!(
            ProviderId::from_cli_name("muse-code"),
            Some(ProviderId::Muse)
        );
        assert_eq!(brand_color(ProviderId::Muse), "#0668E1");
    }

    // The "muse *" alias family spans two providers: bare `muse` / `muse code`
    // are the Muse Code CLI, while `muse spark` belongs to Meta (Meta Muse
    // Spark). Pin the boundary so a future alias edit cannot silently re-route
    // either side (review finding: latent UX/triage trap).
    #[test]
    fn muse_alias_family_boundary() {
        assert_eq!(
            ProviderId::from_cli_name("muse code"),
            Some(ProviderId::Muse)
        );
        assert_eq!(ProviderId::from_cli_name("muse"), Some(ProviderId::Muse));
        assert_eq!(
            ProviderId::from_cli_name("muse spark"),
            Some(ProviderId::Meta)
        );
        assert_eq!(
            ProviderId::from_cli_name("muse-spark"),
            Some(ProviderId::Meta)
        );
        assert_eq!(
            ProviderId::from_cli_name("musespark"),
            Some(ProviderId::Meta)
        );
        assert_eq!(
            ProviderId::from_cli_name("meta muse spark"),
            Some(ProviderId::Meta)
        );
    }

    #[test]
    fn test_provider_id_xai() {
        assert_eq!(ProviderId::Xai.cli_name(), "xai");
        assert_eq!(ProviderId::Xai.display_name(), "xAI");
        assert_eq!(ProviderId::Xai.cookie_domain(), None);
        assert_eq!(ProviderId::from_cli_name("xai"), Some(ProviderId::Xai));
        assert_eq!(ProviderId::from_cli_name("x.ai"), Some(ProviderId::Xai));
        assert_eq!(ProviderId::from_cli_name("x-ai"), Some(ProviderId::Xai));
        // Grok keeps consumer aliases; xai is the developer-platform provider.
        assert_eq!(ProviderId::from_cli_name("grok"), Some(ProviderId::Grok));
        assert_eq!(
            ProviderId::from_cli_name("supergrok"),
            Some(ProviderId::Grok)
        );
    }

    /// The 16 accents upstream 0.70.0 adopted in its palette audit (#4075),
    /// each with the accent Windows shipped before this port.
    const ADOPTED_ACCENTS: [(ProviderId, &str, &str); 16] = [
        (ProviderId::Abacus, "#7C3AED", "#814EE8"),
        (ProviderId::Amp, "#DC2626", "#F34E3F"),
        (ProviderId::Augment, "#6366F1", "#1AA049"),
        (ProviderId::Bedrock, "#FF9900", "#01A88D"),
        (ProviderId::ClinePass, "#61A3FA", "#5487C8"),
        (ProviderId::Codebuff, "#44FF00", "#00FF95"),
        (ProviderId::CommandCode, "#44FF00", "#8C4EDD"),
        (ProviderId::Cursor, "#00BFA5", "#F54E00"),
        (ProviderId::DeepSeek, "#527DF0", "#4D6BFE"),
        (ProviderId::Devin, "#111827", "#317CFF"),
        (ProviderId::Kiro, "#FF9900", "#9046FF"),
        (ProviderId::LongCat, "#FFD100", "#29E154"),
        (ProviderId::Mistral, "#FF500F", "#FF5229"),
        (ProviderId::Neuralwatt, "#38D98C", "#D55934"),
        (ProviderId::Sub2Api, "#2DC6D8", "#14B8A6"),
        (ProviderId::Venice, "#111827", "#3C8FDD"),
    ];

    /// Audited providers whose accent upstream kept, where the Windows accent
    /// already equals upstream's final value. Chutes, Deepgram, Doubao, Groq,
    /// Kilo, LiteLLM, Perplexity, Qoder, Sakana, T3 Chat and Warp keep older
    /// Windows accents that differ from upstream; aligning them is out of
    /// scope for the 0.70.0 port.
    const RETAINED_ACCENTS: [(ProviderId, &str); 7] = [
        (ProviderId::AiAnd, "#E25C2B"),
        (ProviderId::Copilot, "#A855F7"),
        (ProviderId::Fireworks, "#F25B1C"),
        (ProviderId::JetBrains, "#FF3399"),
        (ProviderId::Kimi, "#FE603C"),
        (ProviderId::Notion, "#337EA9"),
        (ProviderId::OpenCode, "#3B82F6"),
    ];

    /// WCAG relative luminance of a `#RRGGBB` color, as upstream's
    /// `ProviderPaletteRegressionTests` computes it.
    fn relative_luminance(hex: &str) -> f64 {
        let digits = hex.strip_prefix('#').expect("hex color starts with #");
        assert_eq!(digits.len(), 6, "{hex} is not #RRGGBB");
        let linear = |offset: usize| {
            let channel =
                f64::from(u8::from_str_radix(&digits[offset..offset + 2], 16).expect("hex digits"))
                    / 255.0;
            if channel <= 0.04045 {
                channel / 12.92
            } else {
                ((channel + 0.055) / 1.055).powf(2.4)
            }
        };
        0.2126 * linear(0) + 0.7152 * linear(2) + 0.0722 * linear(4)
    }

    fn contrast_ratio(color: &str, background: &str) -> f64 {
        let foreground = relative_luminance(color);
        let backdrop = relative_luminance(background);
        (foreground.max(backdrop) + 0.05) / (foreground.min(backdrop) + 0.05)
    }

    #[test]
    fn contrast_ratio_matches_upstream_audit_values() {
        // Rows of upstream docs/provider-palette.md, rounded to two decimals.
        let rounded = |value: f64| (value * 100.0).round() / 100.0;
        assert_eq!(rounded(contrast_ratio("#814EE8", "#FFFFFF")), 5.01);
        assert_eq!(rounded(contrast_ratio("#814EE8", "#222222")), 3.17);
        assert_eq!(rounded(contrast_ratio("#FF9900", "#FFFFFF")), 2.14);
        assert_eq!(rounded(contrast_ratio("#01A88D", "#222222")), 5.29);
        assert_eq!(rounded(contrast_ratio("#00FF95", "#FFFFFF")), 1.33);
        assert_eq!(rounded(contrast_ratio("#FFFFFF", "#FFFFFF")), 1.0);
    }

    #[test]
    fn adopted_upstream_palette_accents_are_pinned() {
        for (id, _, adopted) in ADOPTED_ACCENTS {
            assert_eq!(brand_color(id), adopted, "{id:?}");
        }
        for (id, retained) in RETAINED_ACCENTS {
            assert_eq!(brand_color(id), retained, "{id:?}");
        }
    }

    #[test]
    fn adopted_palette_accents_do_not_materially_regress_contrast() {
        // Upstream's controlled light and dark menu surfaces. A material
        // regression falls below 3:1 while losing at least 0.5 of contrast
        // against the accent Windows shipped before.
        for (id, previous, _) in ADOPTED_ACCENTS {
            for background in ["#FFFFFF", "#222222"] {
                let current = contrast_ratio(brand_color(id), background);
                let before = contrast_ratio(previous, background);
                assert!(
                    current >= 3.0 || before - current < 0.5,
                    "{id:?} on {background}: {before:.2} -> {current:.2}"
                );
            }
        }
    }

    #[test]
    fn brand_colors_are_uppercase_hex() {
        for id in ProviderId::all() {
            let color = brand_color(*id);
            assert!(
                color.len() == 7
                    && color.starts_with('#')
                    && color[1..]
                        .chars()
                        .all(|c| c.is_ascii_digit() || matches!(c, 'A'..='F')),
                "{id:?} has {color}"
            );
        }
    }

    #[test]
    fn test_provider_id_xkiro() {
        assert_eq!(ProviderId::XKiro.cli_name(), "xkiro");
        assert_eq!(ProviderId::XKiro.display_name(), "xKiro");
        assert_eq!(ProviderId::XKiro.cookie_domain(), None);
        assert_eq!(ProviderId::from_cli_name("xkiro"), Some(ProviderId::XKiro));
        assert_eq!(ProviderId::from_cli_name("x-kiro"), Some(ProviderId::XKiro));
        assert_eq!(cli_name_map().get("xkiro"), Some(&ProviderId::XKiro));
        assert_eq!(cli_name_map().get("x-kiro"), Some(&ProviderId::XKiro));
        // xKiro is a separate provider from Kiro and shares none of its aliases.
        assert_eq!(ProviderId::from_cli_name("kiro"), Some(ProviderId::Kiro));
        assert_eq!(ProviderId::from_cli_name("aws"), Some(ProviderId::Kiro));
    }
}
