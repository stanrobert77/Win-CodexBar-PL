//! Local cost-usage scanner for Codex and Claude
//!
//! Scans local JSONL log files to aggregate token usage and calculate costs.
//!
//! Codex production path loads/saves [`crate::core::CostUsageCache`] under
//! `{cache}/CodexBar/cost-usage/`, skips unchanged files by mtime+size, resumes
//! partial files from `parsed_bytes`, honors [`crate::core::CostScanOptions`]
//! debounce (default 60s; `app_driven` forces a fresh inspection), and checks
//! cancel flags between files.

use chrono::{DateTime, Duration, NaiveDate, Utc};
use serde::Deserialize;
use serde_json::Value;
use std::collections::{HashMap, HashSet};
use std::fs::{self, File};
use std::io::{BufRead, BufReader};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::{SystemTime, UNIX_EPOCH};

#[cfg(test)]
use crate::codex_costs::scan_codex_file_cost;
use crate::codex_costs::{
    add_codex_days_map_to_summary, add_codex_records_to_summary, codex_scan_dates,
    merge_codex_records_into_days,
};
use crate::codex_sessions::{codex_sessions_dir_candidates, default_wsl_roots};
use crate::core::{
    CachedCostReport, CodexScanPauseReason, CostScanOptions, CostUsageCache, CostUsageDayRange,
    CostUsageFileUsage, JsonlScanner, ProviderId,
};
use crate::cost_reporting_period::{CostReportingPeriod, MAX_ROLLING_DAYS, cost_bucket_zone};
use crate::providers::claude::quota_history::{
    ClaudeHistoryAttribution, ClaudeQuotaDedupKey, ClaudeQuotaHistoryRecord,
};
use crate::providers::opencodego::local as opencodego_local;
use crate::settings::Settings;
mod claude_incomplete;
mod claude_pricing;
mod claude_roots;
mod claude_usage;
mod codex;
mod read_receipt;
mod stats;
mod window;
pub use claude_incomplete::ClaudeIncompleteReport;
use claude_incomplete::ClaudeIncompleteTracker;
use claude_pricing::ClaudeScanPricingResolver;
#[cfg(test)]
use claude_pricing::{ClaudePricing, FALLBACK_CLAUDE_MODEL};
use claude_usage::{
    ClaudeUsageDedupKey, claude_usage_dedup_key, session_id_from_entries,
    should_count_claude_record,
};
pub use read_receipt::CodexScanReadReceipt;
pub use stats::CostScanStats;

/// Completeness of the pricing coverage in a [`CostSummary`] (upstream 0.48.0 F18).
///
/// `Complete` means every billed model resolved a canonical or fast-rate price.
/// `Partial` means at least one model was deliberately unpriced (routing rows like
/// `codex-auto-review`) or fell back to a legacy default; the breakdown is still
/// shown but the total is labeled partial.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub enum ModelPricingCompleteness {
    /// Every model resolved a canonical price.
    #[default]
    Complete,
    /// At least one model was unpriced or used a fallback rate.
    Partial {
        /// Model IDs that were deliberately unpriced (routing rows).
        unpriced_models: Vec<String>,
    },
}

impl ModelPricingCompleteness {
    pub fn is_partial(&self) -> bool {
        matches!(self, Self::Partial { .. })
    }
}

/// Cost summary from scanning local logs
#[derive(Debug, Clone, Default)]
pub struct CostSummary {
    /// Total cost in USD for the period
    pub total_cost_usd: f64,
    /// Total input tokens
    pub input_tokens: u64,
    /// Total output tokens
    pub output_tokens: u64,
    /// Total cached input tokens
    pub cached_tokens: u64,
    /// Total reasoning tokens when every contributing row reports them
    pub reasoning_tokens: Option<u64>,
    /// Number of sessions/conversations scanned
    pub sessions_count: u32,
    /// Cost breakdown by model
    pub by_model: HashMap<String, f64>,
    /// Token breakdown by model
    pub by_model_tokens: HashMap<String, ModelTokenCounts>,
    /// Codex cost split by speed/tier when local logs expose it.
    pub by_speed: HashMap<String, f64>,
    /// Codex token split by speed/tier when local logs expose it.
    pub by_speed_tokens: HashMap<String, ModelTokenCounts>,
    /// Model IDs that were priced with fallback rates because no canonical rate is available.
    pub unknown_models: HashSet<String>,
    /// Completeness of pricing coverage (Complete vs Partial). Surfaced in the CLI
    /// cost JSON so callers can label a partial breakdown (upstream 0.48.0 F18).
    pub model_pricing_completeness: ModelPricingCompleteness,
    /// Whether the scan's coverage of the requested history window is established
    /// (not pending a catch-up re-scan). `true` when the cache is fresh (within the
    /// debounce window) or the scan just completed; `false` when the cache is stale
    /// or empty and a re-scan would be required (upstream 0.48.0 A16).
    pub history_coverage_established: bool,
    /// True when the scan completed with zero results — a *known* zero, not a
    /// missing scan. Set only when `history_coverage_established` is true and
    /// the scan found no sessions/tokens (upstream 0.50.1 #2932). Never
    /// fabricated on incomplete scans.
    pub known_zero: bool,
    /// Claude preliminary proxy rows (null stop reason, input only) that were
    /// excluded from cost and tokens and never superseded by a completed row
    /// (upstream 0.60.5 #3688). Zero for every other provider.
    pub incomplete_request_count: u32,
    /// Incomplete Claude request counts per model.
    pub incomplete_by_model: HashMap<String, u32>,
    /// Period start date
    pub period_start: Option<NaiveDate>,
    /// Period end date
    pub period_end: Option<NaiveDate>,
}

/// Per-model token counts
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct ModelTokenCounts {
    pub input_tokens: u64,
    pub output_tokens: u64,
    pub cached_tokens: u64,
    pub reasoning_tokens: Option<u64>,
}

impl ModelTokenCounts {
    pub fn total(&self) -> u64 {
        self.input_tokens.saturating_add(self.output_tokens)
    }

    /// Total for sources that report cache reads/writes as classes separate
    /// from `input_tokens` (Claude JSONL). Codex already includes cached input
    /// in `input_tokens`, so use [`Self::total`] there.
    pub fn total_with_separate_cache(&self) -> u64 {
        self.total().saturating_add(self.cached_tokens)
    }

    /// Provider-aware total; see [`cache_is_separate_from_input`].
    pub fn total_for_provider(&self, provider: &str) -> u64 {
        if cache_is_separate_from_input(provider) {
            self.total_with_separate_cache()
        } else {
            self.total()
        }
    }
}

/// Local JSONL sources disagree about whether cache reads are already part of
/// `input_tokens`. Codex reports `input_tokens` with cached input included
/// (`CodexTokenCounts::from_values` clamps `cached` to `input`, and codex
/// pricing subtracts it back out); Claude reports cache read/creation as
/// separate classes. A total must not add the cache bucket for the former.
/// OpenCodex imports are not native rows and keep their own resolved totals
/// (see `spend_contract::opencodex`).
pub fn cache_is_separate_from_input(provider: &str) -> bool {
    provider != "codex"
}

impl CostSummary {
    pub fn format_total(&self) -> String {
        format!("${:.2}", self.total_cost_usd)
    }

    /// Provider-aware window total, same rule as
    /// [`ModelTokenCounts::total_for_provider`].
    pub fn total_tokens_for_provider(&self, provider: &str) -> u64 {
        let total = self.input_tokens.saturating_add(self.output_tokens);
        if cache_is_separate_from_input(provider) {
            total.saturating_add(self.cached_tokens)
        } else {
            total
        }
    }
}

fn is_cancelled(cancel: Option<&AtomicBool>) -> bool {
    cancel.is_some_and(|flag| flag.load(Ordering::Relaxed))
}

fn unix_now_ms() -> i64 {
    // Duration is clamped to i64::MAX before casting, so the value fits i64.
    #[allow(
        clippy::cast_possible_truncation,
        reason = "clamped to i64::MAX before casting"
    )]
    let millis = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis().min(i64::MAX as u128) as i64)
        .unwrap_or(0);
    millis
}

fn system_time_to_unix_ms(modified: Option<SystemTime>) -> i64 {
    // Duration is clamped to i64::MAX before casting, so the value fits i64.
    #[allow(
        clippy::cast_possible_truncation,
        reason = "clamped to i64::MAX before casting"
    )]
    let millis = modified
        .and_then(|t| t.duration_since(UNIX_EPOCH).ok())
        .map(|d| d.as_millis().min(i64::MAX as u128) as i64)
        .unwrap_or(0);
    millis
}

/// JSONL event structures for Codex
#[allow(
    dead_code,
    reason = "JSONL event fields are deserialized for parsing but not all are read"
)]
#[derive(Debug, Deserialize)]
struct CodexEvent {
    #[serde(rename = "type")]
    event_type: Option<String>,
    event_msg: Option<CodexEventMsg>,
}

#[allow(
    dead_code,
    reason = "event message fields are deserialized for parsing but not all are read"
)]
#[derive(Debug, Deserialize)]
struct CodexEventMsg {
    #[serde(rename = "type")]
    msg_type: Option<String>,
    input_tokens: Option<u64>,
    cached_input_tokens: Option<u64>,
    output_tokens: Option<u64>,
}

/// JSONL event structures for Claude transcripts.
///
/// The flattened values retain otherwise-unknown metadata long enough to
/// distinguish Anthropic rows from Vertex AI rows. Claude's local transcript
/// format can contain both shapes, and counting Vertex rows with Anthropic
/// pricing would misstate both cost and token history.
#[derive(Debug, Deserialize)]
struct ClaudeEvent {
    #[serde(rename = "type")]
    event_type: Option<String>,
    timestamp: Option<String>,
    #[serde(rename = "requestId", alias = "request_id")]
    request_id: Option<String>,
    #[serde(rename = "sessionId", alias = "session_id")]
    session_id: Option<String>,
    message: Option<ClaudeMessage>,
    #[serde(flatten)]
    extra: HashMap<String, Value>,
}

impl ClaudeEvent {
    fn parsed_timestamp(&self) -> Option<DateTime<Utc>> {
        let timestamp = self.timestamp.as_deref()?;
        DateTime::parse_from_rfc3339(timestamp)
            .ok()
            .map(|ts| ts.with_timezone(&Utc))
    }

    fn session_id(&self) -> Option<&str> {
        self.session_id
            .as_deref()
            .map(str::trim)
            .filter(|session_id| !session_id.is_empty())
            .or_else(|| session_id_from_entries(self.extra.iter()))
            .or_else(|| {
                self.message
                    .as_ref()
                    .and_then(|message| session_id_from_entries(message.extra.iter()))
            })
    }

    fn is_vertex_ai_usage_entry(&self) -> bool {
        // Vertex AI message/request identifiers use the `_vrtx_` marker.
        if self
            .message
            .as_ref()
            .and_then(|message| message.id.as_deref())
            .is_some_and(|id| id.contains("_vrtx_"))
            || self
                .request_id
                .as_deref()
                .is_some_and(|request_id| request_id.contains("_vrtx_"))
        {
            return true;
        }

        // Vertex AI model names use `@` as the version separator.
        if self
            .message
            .as_ref()
            .and_then(|message| message.model.as_deref())
            .is_some_and(model_name_looks_vertex)
        {
            return true;
        }

        if contains_claude_vertex_metadata_entries(self.extra.iter()) {
            return true;
        }
        self.message
            .as_ref()
            .is_some_and(ClaudeMessage::contains_vertex_metadata)
    }
}

#[derive(Debug, Deserialize)]
struct ClaudeMessage {
    id: Option<String>,
    model: Option<String>,
    usage: Option<ClaudeUsage>,
    #[serde(flatten)]
    extra: HashMap<String, Value>,
}

impl ClaudeMessage {
    fn contains_vertex_metadata(&self) -> bool {
        if contains_claude_vertex_metadata_entries(self.extra.iter()) {
            return true;
        }
        self.usage
            .as_ref()
            .is_some_and(ClaudeUsage::contains_vertex_metadata)
    }
}

/// Claude Code proxies can emit a cache-unaware `message_start` estimate
/// before the final assistant response. It has a null stop reason, input
/// tokens, no output, and no cache breakdown; pricing that row would count a
/// preliminary estimate alongside the eventual final usage.
fn is_preliminary_claude_usage(event: &ClaudeEvent) -> bool {
    if event.event_type.as_deref() != Some("assistant") {
        return false;
    }
    let Some(message) = event.message.as_ref() else {
        return false;
    };
    let Some(usage) = message.usage.as_ref() else {
        return false;
    };

    message.extra.get("stop_reason").is_some_and(Value::is_null)
        && usage.input_tokens.unwrap_or(0) > 0
        && usage.output_tokens.unwrap_or(0) == 0
        && usage.cache_read_input_tokens.is_none()
        && usage.cache_creation_input_tokens.is_none()
}

#[derive(Debug, Deserialize)]
struct ClaudeUsage {
    input_tokens: Option<u64>,
    output_tokens: Option<u64>,
    cache_creation_input_tokens: Option<u64>,
    cache_read_input_tokens: Option<u64>,
    cache_creation: Option<ClaudeCacheCreation>,
    #[serde(flatten)]
    extra: HashMap<String, Value>,
}

impl ClaudeUsage {
    fn contains_vertex_metadata(&self) -> bool {
        if contains_claude_vertex_metadata_entries(self.extra.iter()) {
            return true;
        }
        self.cache_creation
            .as_ref()
            .is_some_and(ClaudeCacheCreation::contains_vertex_metadata)
    }
}

impl ClaudeUsage {
    /// One-hour cache-write tokens, clamped to the total cache-write count.
    fn one_hour_cache_creation_tokens(&self, total: u64) -> u64 {
        self.cache_creation
            .as_ref()
            .and_then(|cache_creation| cache_creation.ephemeral_1h_input_tokens)
            .unwrap_or(0)
            .min(total)
    }
}

/// TTL breakdown of cache writes reported by the API.
#[derive(Debug, Deserialize)]
struct ClaudeCacheCreation {
    ephemeral_1h_input_tokens: Option<u64>,
    #[serde(flatten)]
    extra: HashMap<String, Value>,
}

impl ClaudeCacheCreation {
    fn contains_vertex_metadata(&self) -> bool {
        contains_claude_vertex_metadata_entries(self.extra.iter())
    }
}

const CLAUDE_VERTEX_PROVIDER_KEYS: &[&str] = &[
    "provider",
    "platform",
    "backend",
    "api_provider",
    "apiprovider",
    "api_type",
    "apitype",
    "source",
    "vendor",
    "client",
];

fn model_name_looks_vertex(model: &str) -> bool {
    model.starts_with("claude-") && model.contains('@')
}

/// Match the upstream Claude classifier's recursive metadata rules. Marker
/// keys (`vertex`/`gcp`) classify regardless of value; provider-key values
/// classify only when their text contains `vertex` (not merely `gcp`).
fn contains_claude_vertex_metadata(value: &Value) -> bool {
    match value {
        Value::Object(object) => contains_claude_vertex_metadata_entries(object.iter()),
        Value::Array(array) => array.iter().any(contains_claude_vertex_metadata),
        Value::Null | Value::Bool(_) | Value::Number(_) | Value::String(_) => false,
    }
}

fn contains_claude_vertex_metadata_entries<'a, I>(entries: I) -> bool
where
    I: IntoIterator<Item = (&'a String, &'a Value)>,
{
    entries.into_iter().any(|(key, value)| {
        contains_claude_vertex_marker(key, true)
            || (CLAUDE_VERTEX_PROVIDER_KEYS
                .iter()
                .any(|candidate| key.eq_ignore_ascii_case(candidate))
                && value
                    .as_str()
                    .is_some_and(|text| contains_claude_vertex_marker(text, false)))
            || contains_claude_vertex_metadata(value)
    })
}

fn contains_claude_vertex_marker(value: &str, include_gcp: bool) -> bool {
    let bytes = value.as_bytes();
    let has_marker = |marker: &[u8]| {
        bytes.windows(marker.len()).any(|window| {
            window
                .iter()
                .zip(marker)
                .all(|(byte, expected)| byte.to_ascii_lowercase() == *expected)
        })
    };

    if has_marker(b"vertex") || (include_gcp && has_marker(b"gcp")) {
        return true;
    }

    // ASCII folding above is enough for the common path. Unicode lowercasing
    // preserves the historical classifier's behavior for non-ASCII strings.
    if value.is_ascii() {
        return false;
    }
    let lower = value.to_lowercase();
    lower.contains("vertex") || (include_gcp && lower.contains("gcp"))
}

#[derive(Debug)]
struct ClaudeUsageRecord {
    model: String,
    pricing_known: bool,
    timestamp: Option<DateTime<Utc>>,
    dedup_key: Option<ClaudeUsageDedupKey>,
    input: u64,
    output: u64,
    cache_create: u64,
    cache_read: u64,
    /// `None` means pricing was unavailable or produced a non-finite value.
    /// Keep that distinct from a real zero-dollar row.
    cost: Option<f64>,
}

/// Exact Claude request rows retained for quota-window projection.
///
/// This is intentionally separate from [`CostSummary`].  The summary is a
/// presentation aggregate, while quota history needs timestamps, dedup keys,
/// and independent completeness for tokens and pricing.
#[derive(Debug, Clone, Default)]
pub struct ClaudeQuotaHistoryScan {
    pub records: Vec<ClaudeQuotaHistoryRecord>,
    pub history_coverage_established: bool,
}

/// All chart-facing Claude history derived from one project-tree traversal.
///
/// The result keeps provider parsing and aggregation in Rust so callers can
/// render daily cost, daily tokens, local summary, and quota windows without
/// starting independent Claude scans. Transcript rows are deliberately marked
/// as unattributed until a trustworthy historical account signal exists.
#[derive(Debug, Clone)]
pub struct ClaudeChartSnapshot {
    pub summary: CostSummary,
    pub daily_cost: Vec<(String, Option<f64>)>,
    pub daily_tokens: Vec<(String, u64)>,
    /// Incomplete request count per local day; only days with a count appear.
    pub daily_incomplete: Vec<(String, u32)>,
    pub quota_history: ClaudeQuotaHistoryScan,
}
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
struct ClaudeFileScanResult {
    counted: usize,
    malformed_lines: u32,
    incomplete_requests: u32,
    read_failures: u32,
    aggregation_failures: u32,
}

impl ClaudeFileScanResult {
    fn absorb(&mut self, other: Self) {
        self.counted += other.counted;
        self.malformed_lines = self.malformed_lines.saturating_add(other.malformed_lines);
        self.incomplete_requests = self
            .incomplete_requests
            .saturating_add(other.incomplete_requests);
        self.read_failures = self.read_failures.saturating_add(other.read_failures);
        self.aggregation_failures = self
            .aggregation_failures
            .saturating_add(other.aggregation_failures);
    }

    fn is_complete(self) -> bool {
        self.malformed_lines == 0
            && self.incomplete_requests == 0
            && self.read_failures == 0
            && self.aggregation_failures == 0
    }
}

#[derive(Debug, Clone)]
pub struct CostScanner {
    /// The window every scan resolves at its own start (never cached as dates).
    period: CostReportingPeriod,
    options: CostScanOptions,
    cache_root: Option<PathBuf>,
    /// When set, bypass normal sessions-dir discovery (tests / inject roots).
    sessions_dirs_override: Option<Vec<PathBuf>>,
    /// Explicit Codex trace database (tests / inject roots). Without it the
    /// ambient `CODEX_HOME` database is used, unless sessions dirs are injected.
    codex_trace_database_override: Option<PathBuf>,
}

impl CostScanner {
    /// Create a new scanner for the last N days (default 60s cache debounce).
    pub fn new(days: u32) -> Self {
        Self::for_period(CostReportingPeriod::Rolling(days))
    }

    /// Create a scanner for a reporting period. `new(days)` is
    /// `for_period(CostReportingPeriod::Rolling(days))`.
    pub fn for_period(period: CostReportingPeriod) -> Self {
        Self {
            period,
            options: CostScanOptions::default(),
            cache_root: None,
            sessions_dirs_override: None,
            codex_trace_database_override: None,
        }
    }

    /// The reporting period this scanner resolves on every scan.
    pub fn period(&self) -> CostReportingPeriod {
        self.period
    }

    /// Override scan options (e.g. [`CostScanOptions::app_driven`] for force refresh).
    pub fn with_options(mut self, options: CostScanOptions) -> Self {
        self.options = options;
        self
    }

    /// Override on-disk cache root (`{root}/cost-usage/…`).
    pub fn with_cache_root(mut self, root: impl Into<PathBuf>) -> Self {
        self.cache_root = Some(root.into());
        self
    }

    /// Override Codex sessions roots (primarily for tests).
    pub fn with_sessions_dirs(mut self, dirs: Vec<PathBuf>) -> Self {
        self.sessions_dirs_override = Some(dirs);
        self
    }

    /// Override the Codex Priority trace database (primarily for tests).
    pub fn with_codex_trace_database(mut self, path: impl Into<PathBuf>) -> Self {
        self.codex_trace_database_override = Some(path.into());
        self
    }

    /// Scan standalone Pi and OMP local history.
    ///
    /// Pi session rows can represent either Codex or Claude models. They are
    /// priced with the mapped provider's table but owned by the standalone Pi
    /// source, so this path never adds native Codex/Claude transcripts.
    pub fn scan_pi(&self) -> CostSummary {
        self.scan_pi_with_cancel(None)
    }

    pub fn scan_pi_with_cancel(&self, cancel: Option<&AtomicBool>) -> CostSummary {
        let now = Utc::now();
        let window = self.transcript_window(now, now.date_naive());
        let mut summary = CostSummary {
            period_start: Some(window.start),
            period_end: Some(window.end),
            ..CostSummary::default()
        };
        let mut seen_entries = HashSet::new();
        let evidence = crate::pi_session_cost::scan_pi_into(
            &mut summary,
            window.cutoff,
            cancel,
            &mut seen_entries,
        );
        summary.history_coverage_established = evidence.complete && !is_cancelled(cancel);
        summary.known_zero = summary.history_coverage_established
            && summary.sessions_count == 0
            && summary.input_tokens == 0
            && summary.output_tokens == 0
            && summary.cached_tokens == 0;
        summary
    }

    /// Scan Codex local logs
    pub fn scan_claude(&self) -> CostSummary {
        self.scan_claude_with_cancel(None)
    }

    /// Scan Claude local logs, stopping early when the caller cancels the scan.
    pub fn scan_claude_with_cancel(&self, cancel: Option<&AtomicBool>) -> CostSummary {
        self.scan_claude_with_cancel_and_pi_sessions(cancel, true)
    }

    /// Scan Claude local logs with optional Pi/OMP-compatible history.
    ///
    /// The default scanner remains inclusive for backwards compatibility. A
    /// combined Codex/Claude/Pi selection can turn this off so the standalone
    /// Pi row owns those mirrored events exactly once.
    pub fn scan_claude_with_cancel_and_pi_sessions(
        &self,
        cancel: Option<&AtomicBool>,
        include_pi_sessions: bool,
    ) -> CostSummary {
        let roots = self.claude_projects_roots();
        let mut summary = CostSummary::default();
        let now = Utc::now();
        let window = self.transcript_window(now, now.date_naive());
        let cutoff = window.cutoff;

        summary.period_start = Some(window.start);
        summary.period_end = Some(window.end);

        // Walk through projects directory, de-duplicating usage records
        // that appear across multiple files.
        let mut claude_scan = ClaudeFileScanResult::default();
        let mut incomplete = ClaudeIncompleteTracker::default();
        let mut completed_keys = HashSet::new();
        if !roots.paths.is_empty() {
            let mut seen = HashSet::new();
            let mut pricing = ClaudeScanPricingResolver::default();
            let traversal_read_failures = {
                let mut handle_file = |path: &Path| {
                    let mut aggregation_complete = true;
                    let mut file_result = scan_claude_file_with_pricing(
                        path,
                        &cutoff,
                        &mut seen,
                        cancel,
                        &mut pricing,
                        &mut incomplete,
                        |record| {
                            aggregation_complete &= record.timestamp.is_some();
                            aggregation_complete &=
                                add_claude_record_to_summary(&mut summary, record);
                        },
                    );
                    if !aggregation_complete {
                        file_result.aggregation_failures =
                            file_result.aggregation_failures.saturating_add(1);
                    }
                    if file_result.counted > 0 {
                        summary.sessions_count += 1;
                    }
                    claude_scan.absorb(file_result);
                };
                self.walk_claude_roots(&roots.paths, &cutoff, cancel, &mut handle_file)
            };
            claude_scan.read_failures = claude_scan
                .read_failures
                .saturating_add(roots.read_failures)
                .saturating_add(traversal_read_failures);
            completed_keys = seen;
        }
        incomplete.resolve(&completed_keys).apply_to(&mut summary);

        // OMP / pi-compatible anthropic rows, deduped across shared files.
        if include_pi_sessions {
            let mut seen_pi = HashSet::new();
            crate::pi_session_cost::scan_pi_compatible_into(
                &mut summary,
                crate::pi_session_cost::PiMappedProvider::Claude,
                cutoff,
                cancel,
                &mut seen_pi,
            );
        }

        // Claude has no persisted provider cost-report cache in the Windows
        // port. Rebuilding from the transcript inventory on every scan makes
        // pricing-semantics changes naturally reprice older rows. A malformed
        // line or preliminary proxy estimate keeps coverage unknown rather
        // than turning a partial zero into a known zero.
        finalize_claude_summary(
            &mut summary,
            !roots.paths.is_empty(),
            claude_scan,
            is_cancelled(cancel),
        );

        summary
    }

    /// Scan Claude chart evidence once and derive every chart input from the
    /// same de-duplicated record stream.
    pub fn scan_claude_chart_snapshot_with_cancel(
        &self,
        cancel: Option<&AtomicBool>,
    ) -> ClaudeChartSnapshot {
        let roots = self.claude_projects_roots();
        let now = Utc::now();
        let window = self.transcript_window(now, cost_bucket_zone().date(now));
        let cutoff = window.cutoff;
        let mut summary = CostSummary {
            period_start: Some(window.start),
            period_end: Some(window.end),
            ..CostSummary::default()
        };
        let mut daily_cost = HashMap::new();
        let mut daily_tokens = HashMap::new();
        // The chart never shows more than a year of daily slots, so an
        // all-available window does not allocate one per day since 1970.
        let slot_days = match self.period {
            CostReportingPeriod::Rolling(days) => days,
            CostReportingPeriod::MonthToDate | CostReportingPeriod::AllAvailable => {
                window.days.min(MAX_ROLLING_DAYS)
            }
        };
        let mut unknown_cost_dates = HashSet::new();
        for days_ago in 0..slot_days {
            let date = window.end - Duration::days(days_ago as i64);
            let key = date.format("%Y-%m-%d").to_string();
            daily_cost.insert(key.clone(), None);
            daily_tokens.insert(key, 0);
        }

        let mut quota_records = Vec::new();
        let mut scan_result = ClaudeFileScanResult::default();
        let mut incomplete = ClaudeIncompleteTracker::default();
        let mut completed_keys = HashSet::new();
        if !roots.paths.is_empty() {
            let mut seen = HashSet::new();
            let mut pricing = ClaudeScanPricingResolver::default();
            let traversal_read_failures =
                self.walk_claude_roots(&roots.paths, &cutoff, cancel, &mut |path| {
                    let mut file_has_usage = false;
                    let mut aggregation_complete = true;
                    let mut file_result = scan_claude_file_with_pricing(
                        path,
                        &cutoff,
                        &mut seen,
                        cancel,
                        &mut pricing,
                        &mut incomplete,
                        |record| {
                            file_has_usage = true;
                            aggregation_complete &= record.timestamp.is_some();
                            aggregation_complete &=
                                add_claude_record_to_summary(&mut summary, record);
                            aggregation_complete &= add_claude_record_to_daily_costs(
                                &mut daily_cost,
                                &mut unknown_cost_dates,
                                record,
                            );
                            aggregation_complete &=
                                add_claude_record_to_daily_tokens(&mut daily_tokens, record);
                            if let Some(quota_record) = quota_history_record_from_usage(record) {
                                quota_records.push(quota_record);
                            }
                        },
                    );
                    if !aggregation_complete {
                        file_result.aggregation_failures =
                            file_result.aggregation_failures.saturating_add(1);
                    }
                    if file_has_usage {
                        summary.sessions_count += 1;
                    }
                    scan_result.absorb(file_result);
                });
            scan_result.read_failures = scan_result
                .read_failures
                .saturating_add(roots.read_failures)
                .saturating_add(traversal_read_failures);
            completed_keys = seen;
        }
        let incomplete_report = incomplete.resolve(&completed_keys);
        incomplete_report.apply_to(&mut summary);

        crate::pi_session_cost::scan_pi_compatible_into(
            &mut summary,
            crate::pi_session_cost::PiMappedProvider::Claude,
            cutoff,
            cancel,
            &mut HashSet::new(),
        );

        let complete =
            !roots.paths.is_empty() && !is_cancelled(cancel) && scan_result.is_complete();
        finalize_claude_summary(
            &mut summary,
            !roots.paths.is_empty(),
            scan_result,
            is_cancelled(cancel),
        );
        if complete {
            zero_fill_uninitialized_claude_daily_costs(&mut daily_cost, &unknown_cost_dates);
        }

        let mut daily_cost = daily_cost.into_iter().collect::<Vec<_>>();
        daily_cost.sort_by(|left, right| left.0.cmp(&right.0));
        let mut daily_tokens = daily_tokens.into_iter().collect::<Vec<_>>();
        daily_tokens.sort_by(|left, right| left.0.cmp(&right.0));
        ClaudeChartSnapshot {
            summary,
            daily_cost,
            daily_tokens,
            daily_incomplete: incomplete_report.daily_sorted(),
            quota_history: ClaudeQuotaHistoryScan {
                records: quota_records,
                history_coverage_established: complete,
            },
        }
    }

    /// Scan Claude transcript rows for display-only quota-window history.
    ///
    /// The parser, preliminary-row filtering, provider filtering, and
    /// request/session deduplication are shared with the ordinary Claude cost
    /// summary path.  Missing timestamps or incomplete file reads keep the
    /// coverage flag false; callers must not present those rows as an exact
    /// historical total.
    pub fn scan_claude_quota_history(&self) -> ClaudeQuotaHistoryScan {
        self.scan_claude_quota_history_with_cancel(None)
    }

    /// Cancellable form of [`Self::scan_claude_quota_history`].
    pub fn scan_claude_quota_history_with_cancel(
        &self,
        cancel: Option<&AtomicBool>,
    ) -> ClaudeQuotaHistoryScan {
        self.scan_claude_chart_snapshot_with_cancel(cancel)
            .quota_history
    }
    /// Scan OpenCode Go local SQLite usage (upstream #2649 per-model cost breakdown).
    ///
    /// Reads the local `opencode.db` and maps rows onto the shared `CostSummary`
    /// (`total_cost_usd`, `by_model`, `sessions_count`, period) so the chart's
    /// local-usage summary treats OpenCode Go like Codex/Claude. Recorded token
    /// counts fill the token fields and `by_model_tokens` (costs stay the recorded
    /// `cost`, never derived from tokens). Rows without usable tokens add nothing
    /// to the sums, and `reasoning_tokens` stays `None` unless every row reports it.
    fn scan_opencodego_model_cost_summary_with_cancel(
        &self,
        cancel: Option<&AtomicBool>,
    ) -> Option<opencodego_local::ModelCostSummary> {
        if is_cancelled(cancel) {
            return None;
        }
        let now = Utc::now();
        let days = self.calendar_window(now, None).days;
        opencodego_local::model_cost_summary_scan(now, days)
    }

    pub fn scan_opencodego_with_cancel(&self, cancel: Option<&AtomicBool>) -> CostSummary {
        let Some(local) = self.scan_opencodego_model_cost_summary_with_cancel(cancel) else {
            return CostSummary::default();
        };
        let totals = local.tokens.to_model_token_counts().unwrap_or_default();
        let by_model_tokens = local
            .by_model_tokens
            .iter()
            .filter_map(|(model, sums)| {
                sums.to_model_token_counts()
                    .map(|counts| (model.clone(), counts))
            })
            .collect();
        CostSummary {
            total_cost_usd: local.total_cost_usd,
            input_tokens: totals.input_tokens,
            output_tokens: totals.output_tokens,
            cached_tokens: totals.cached_tokens,
            reasoning_tokens: totals.reasoning_tokens,
            by_model: local.by_model,
            by_model_tokens,
            sessions_count: local.request_count,
            period_start: local.period_start,
            period_end: local.period_end,
            ..CostSummary::default()
        }
    }

    /// Return the exact local input + output token total for Usage & Spend.
    /// `None` when any contributing row lacks usable input/output counts.
    pub fn scan_opencodego_usage_tokens_with_cancel(
        &self,
        cancel: Option<&AtomicBool>,
    ) -> Option<u64> {
        self.scan_opencodego_model_cost_summary_with_cancel(cancel)?
            .tokens
            .complete_input_output()
    }

    /// Existing Claude transcript roots: the profile root plus claude-swap
    /// session homes, de-duplicated by resolved path.
    fn claude_projects_roots(&self) -> claude_roots::ClaudeProjectsRoots {
        claude_roots::claude_projects_roots(
            std::env::var("CLAUDE_CONFIG_DIR").ok().as_deref(),
            dirs::home_dir().as_deref(),
        )
    }

    /// Walk every root with one caller-owned `seen` set behind `on_file`, so a
    /// row copied between homes is counted once. Returns read failures.
    fn walk_claude_roots<F>(
        &self,
        roots: &[PathBuf],
        cutoff: &DateTime<Utc>,
        cancel: Option<&AtomicBool>,
        on_file: &mut F,
    ) -> u32
    where
        F: FnMut(&Path),
    {
        roots.iter().fold(0u32, |failures, root| {
            failures.saturating_add(self.walk_claude_files(root, cutoff, cancel, on_file))
        })
    }

    fn walk_claude_files<F>(
        &self,
        dir: &Path,
        cutoff: &DateTime<Utc>,
        cancel: Option<&AtomicBool>,
        on_file: &mut F,
    ) -> u32
    where
        F: FnMut(&Path),
    {
        if is_cancelled(cancel) {
            return 0;
        }
        let entries = match fs::read_dir(dir) {
            Ok(e) => e,
            Err(_) => return 1,
        };

        let mut read_failures = 0u32;
        for entry in entries {
            if is_cancelled(cancel) {
                break;
            }
            let entry = match entry {
                Ok(entry) => entry,
                Err(_) => {
                    read_failures = read_failures.saturating_add(1);
                    continue;
                }
            };
            let path = entry.path();
            match fs::metadata(&path) {
                Ok(metadata) if metadata.is_dir() => {
                    read_failures = read_failures
                        .saturating_add(self.walk_claude_files(&path, cutoff, cancel, on_file));
                }
                Ok(metadata) if path.extension().is_some_and(|e| e == "jsonl") => {
                    match metadata.modified() {
                        Ok(modified) => {
                            let modified_dt: DateTime<Utc> = modified.into();
                            if modified_dt >= *cutoff {
                                on_file(&path);
                            }
                        }
                        Err(_) => read_failures = read_failures.saturating_add(1),
                    }
                }
                Ok(_) => {}
                Err(_) => read_failures = read_failures.saturating_add(1),
            }
        }
        read_failures
    }
}

/// Stream the de-duplicated, in-window usage records from one transcript
/// file into `on_record`. Both the summary scan and the daily-history scan
/// consume this single reader, so Claude log semantics live in one place.
/// Returns the number of records consumed, so callers can tell whether the
/// file contributed anything.
#[cfg(test)]
fn for_each_claude_usage_record<F>(
    path: &Path,
    cutoff: &DateTime<Utc>,
    seen: &mut HashSet<ClaudeUsageDedupKey>,
    cancel: Option<&AtomicBool>,
    on_record: F,
) -> usize
where
    F: FnMut(&ClaudeUsageRecord),
{
    let mut pricing = ClaudeScanPricingResolver::default();
    let mut incomplete = ClaudeIncompleteTracker::default();
    scan_claude_file_with_pricing(
        path,
        cutoff,
        seen,
        cancel,
        &mut pricing,
        &mut incomplete,
        on_record,
    )
    .counted
}

fn scan_claude_file_with_pricing<F>(
    path: &Path,
    cutoff: &DateTime<Utc>,
    seen: &mut HashSet<ClaudeUsageDedupKey>,
    cancel: Option<&AtomicBool>,
    pricing: &mut ClaudeScanPricingResolver,
    incomplete: &mut ClaudeIncompleteTracker,
    mut on_record: F,
) -> ClaudeFileScanResult
where
    F: FnMut(&ClaudeUsageRecord),
{
    let Ok(file) = File::open(path) else {
        return ClaudeFileScanResult {
            read_failures: 1,
            ..ClaudeFileScanResult::default()
        };
    };

    let mut result = ClaudeFileScanResult::default();
    // Use read_until so a final incomplete line (no trailing newline) is still
    // processed when it is valid UTF-8 JSON, and so a single bad line does not
    // stop the walk the way `lines().map_while(Result::ok)` would.
    let line_result = for_each_jsonl_text_line(BufReader::new(file), |line| {
        if is_cancelled(cancel) {
            return false;
        }
        if line.trim().is_empty() {
            return true;
        }
        let Ok(event) = serde_json::from_str::<ClaudeEvent>(line) else {
            result.malformed_lines = result.malformed_lines.saturating_add(1);
            return true;
        };
        if event.is_vertex_ai_usage_entry() {
            return true;
        }
        if is_preliminary_claude_usage(&event) {
            result.incomplete_requests = result.incomplete_requests.saturating_add(1);
            if let Some(message) = event.message.as_ref() {
                incomplete.record(
                    claude_usage_dedup_key(
                        message.id.as_deref(),
                        event.request_id.as_deref(),
                        event.session_id(),
                    ),
                    message.model.as_deref().unwrap_or("claude-3-5-sonnet"),
                    event.parsed_timestamp(),
                    cutoff,
                );
            }
            return true;
        }
        if let Some(record) = claude_usage_record_from_event_with_pricing(&event, pricing)
            && should_count_claude_record(&record, cutoff, seen)
        {
            result.counted += 1;
            on_record(&record);
        }
        true
    });
    result.malformed_lines = result
        .malformed_lines
        .saturating_add(line_result.malformed_lines);
    result.read_failures = line_result.read_failures;
    result
}

/// Walk JSONL text lines from `reader`, including a final incomplete line at EOF.
/// Continues past invalid UTF-8 segments. `on_line` returns `false` to stop early.
fn for_each_jsonl_text_line<R, F>(mut reader: R, mut on_line: F) -> ClaudeJsonlLineResult
where
    R: BufRead,
    F: FnMut(&str) -> bool,
{
    let mut result = ClaudeJsonlLineResult::default();
    let mut buf = Vec::new();
    loop {
        buf.clear();
        match reader.read_until(b'\n', &mut buf) {
            Ok(0) => break,
            Ok(_) => {}
            Err(_) => {
                result.read_failures = result.read_failures.saturating_add(1);
                break;
            }
        }
        while matches!(buf.last(), Some(b'\n' | b'\r')) {
            buf.pop();
        }
        let Ok(line) = std::str::from_utf8(&buf) else {
            result.malformed_lines = result.malformed_lines.saturating_add(1);
            continue;
        };
        if !on_line(line) {
            break;
        }
    }
    result
}

#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
struct ClaudeJsonlLineResult {
    malformed_lines: u32,
    read_failures: u32,
}

fn finalize_claude_summary(
    summary: &mut CostSummary,
    projects_dir_exists: bool,
    scan_result: ClaudeFileScanResult,
    cancelled: bool,
) {
    let complete = projects_dir_exists && !cancelled && scan_result.is_complete();
    summary.history_coverage_established = complete;
    summary.known_zero = complete
        && summary.sessions_count == 0
        && summary.input_tokens == 0
        && summary.output_tokens == 0
        && summary.cached_tokens == 0
        && summary.total_cost_usd == 0.0;
}

#[cfg(test)]
fn claude_usage_record_from_event(event: &ClaudeEvent) -> Option<ClaudeUsageRecord> {
    let mut pricing = ClaudeScanPricingResolver::default();
    claude_usage_record_from_event_with_pricing(event, &mut pricing)
}

fn claude_usage_record_from_event_with_pricing(
    event: &ClaudeEvent,
    pricing: &mut ClaudeScanPricingResolver,
) -> Option<ClaudeUsageRecord> {
    if event.event_type.as_deref() != Some("assistant") || is_preliminary_claude_usage(event) {
        return None;
    }

    let message = event.message.as_ref()?;
    let usage = message.usage.as_ref()?;
    let model = message.model.as_deref().unwrap_or("claude-3-5-sonnet");

    let input = usage.input_tokens.unwrap_or(0);
    let output = usage.output_tokens.unwrap_or(0);
    let cache_create = usage.cache_creation_input_tokens.unwrap_or(0);
    let cache_read = usage.cache_read_input_tokens.unwrap_or(0);

    if input == 0 && output == 0 && cache_create == 0 && cache_read == 0 {
        return None;
    }

    let cache_create_1h = usage.one_hour_cache_creation_tokens(cache_create);
    let pricing_known = pricing.is_known(model);
    let computed_cost = pricing.cost_usd_with_cache_ttl(
        model,
        input,
        cache_create,
        cache_create_1h,
        cache_read,
        output,
    );
    let cost = computed_cost.is_finite().then_some(computed_cost);

    Some(ClaudeUsageRecord {
        model: model.to_string(),
        pricing_known,
        timestamp: event.parsed_timestamp(),
        dedup_key: claude_usage_dedup_key(
            message.id.as_deref(),
            event.request_id.as_deref(),
            event.session_id(),
        ),
        input,
        output,
        cache_create,
        cache_read,
        cost,
    })
}

fn add_claude_record_to_summary(summary: &mut CostSummary, record: &ClaudeUsageRecord) -> bool {
    if !record.pricing_known {
        summary.unknown_models.insert(record.model.clone());
    }

    let mut complete = checked_add_assign(&mut summary.input_tokens, record.input);
    complete &= checked_add_assign(&mut summary.output_tokens, record.output);
    let cached = record.cache_create.checked_add(record.cache_read);
    complete &= cached.is_some_and(|value| checked_add_assign(&mut summary.cached_tokens, value));

    if let Some(cost) = record.cost {
        complete &= checked_add_finite(&mut summary.total_cost_usd, cost);
        complete &= checked_add_finite(
            summary.by_model.entry(record.model.clone()).or_insert(0.0),
            cost,
        );
    } else {
        complete = false;
    }

    let model_tokens = summary
        .by_model_tokens
        .entry(record.model.clone())
        .or_default();
    complete &= checked_add_assign(&mut model_tokens.input_tokens, record.input);
    complete &= checked_add_assign(&mut model_tokens.output_tokens, record.output);
    complete &=
        cached.is_some_and(|value| checked_add_assign(&mut model_tokens.cached_tokens, value));
    complete
}

fn checked_add_assign(total: &mut u64, value: u64) -> bool {
    let Some(sum) = total.checked_add(value) else {
        return false;
    };
    *total = sum;
    true
}

fn checked_add_finite(total: &mut f64, value: f64) -> bool {
    let sum = *total + value;
    if !value.is_finite() || !sum.is_finite() {
        return false;
    }
    *total = sum;
    true
}

fn quota_history_record_from_usage(record: &ClaudeUsageRecord) -> Option<ClaudeQuotaHistoryRecord> {
    let timestamp = record.timestamp?;
    let tokens = record
        .input
        .checked_add(record.output)
        .and_then(|value| value.checked_add(record.cache_create))
        .and_then(|value| value.checked_add(record.cache_read));
    let dedup_key = record.dedup_key.as_ref().map(|key| match key {
        ClaudeUsageDedupKey::Request {
            message_id,
            request_id,
        } => ClaudeQuotaDedupKey::Request {
            message_id: message_id.clone(),
            request_id: request_id.clone(),
        },
        ClaudeUsageDedupKey::Session {
            session_id,
            message_id,
        } => ClaudeQuotaDedupKey::Session {
            session_id: session_id.clone(),
            message_id: message_id.clone(),
        },
    });
    Some(ClaudeQuotaHistoryRecord {
        timestamp,
        tokens,
        cost_usd: record.cost,
        tokens_are_complete: tokens.is_some(),
        cost_is_complete: record.pricing_known && record.cost.is_some_and(|cost| cost >= 0.0),
        dedup_key,
        attribution: ClaudeHistoryAttribution::Unavailable,
    })
}

/// Add one usage record to the per-day cost buckets, keyed by the record's
/// own timestamp in the pinned bucket zone. Records outside the initialized
/// date range (or without a timestamp) are ignored.
fn add_claude_record_to_daily_costs(
    daily_costs: &mut HashMap<String, Option<f64>>,
    unknown_cost_dates: &mut HashSet<String>,
    record: &ClaudeUsageRecord,
) -> bool {
    let Some(timestamp) = record.timestamp else {
        return true;
    };
    let date_str = cost_bucket_zone()
        .date(timestamp)
        .format("%Y-%m-%d")
        .to_string();
    if let Some(cost) = daily_costs.get_mut(&date_str) {
        if unknown_cost_dates.contains(&date_str) {
            return false;
        }
        let Some(record_cost) = record.cost else {
            *cost = None;
            unknown_cost_dates.insert(date_str);
            return false;
        };
        let sum = cost.unwrap_or(0.0) + record_cost;
        if !sum.is_finite() {
            *cost = None;
            unknown_cost_dates.insert(date_str);
            return false;
        }
        *cost = Some(sum);
    }
    true
}

fn zero_fill_uninitialized_claude_daily_costs(
    daily_costs: &mut HashMap<String, Option<f64>>,
    unknown_cost_dates: &HashSet<String>,
) {
    for (day, cost) in daily_costs {
        if cost.is_none() && !unknown_cost_dates.contains(day) {
            *cost = Some(0.0);
        }
    }
}

/// Check if any cost usage sources are available
#[allow(
    dead_code,
    reason = "utility probe for cost-usage availability; not yet wired into all call sites"
)]
pub fn has_cost_usage_sources() -> bool {
    let scanner = CostScanner::new(1);
    scanner
        .get_codex_sessions_dirs()
        .iter()
        .any(|dir| dir.exists())
        || scanner.claude_projects_roots().has_possible_roots()
        || crate::pi_session_cost::pi_compatible_session_roots(dirs::home_dir())
            .iter()
            .any(|dir| dir.exists())
}

/// Get daily cost history for the last N days
/// Returns calendar-preserving daily costs sorted by date. `None` means the day
/// is unscanned or contains unpriced Codex usage; `Some(0)` is a known zero.
pub fn get_daily_cost_history(provider: &str, days: u32) -> Vec<(String, Option<f64>)> {
    get_daily_cost_and_incomplete_history(provider, days).0
}

/// Daily cost series plus per-day incomplete request counts.
pub type DailyCostAndIncomplete = (Vec<(String, Option<f64>)>, Vec<(String, u32)>);

/// Daily cost history plus, for Claude, the per-day count of incomplete proxy
/// requests (upstream 0.60.5 #3688). Days with no incomplete request are
/// absent from the second vector; it is empty for every other provider.
pub fn get_daily_cost_and_incomplete_history(provider: &str, days: u32) -> DailyCostAndIncomplete {
    let mut daily_incomplete = Vec::new();
    let scanner = CostScanner::new(days);
    let today = cost_bucket_zone().date(Utc::now());
    let mut daily_costs: HashMap<String, Option<f64>> = HashMap::new();

    // Initialize all days with 0
    for days_ago in 0..days {
        let date = today - Duration::days(days_ago as i64);
        let date_str = date.format("%Y-%m-%d").to_string();
        daily_costs.insert(
            date_str,
            (provider != "codex" && provider != "claude" && provider != "pi").then_some(0.0),
        );
    }

    match provider {
        "codex" => {
            // Warm/refresh the disk cache, then price from packed days. v0.56.1
            // preserves every calendar slot and distinguishes covered zero from
            // unscanned/unpriced history.
            let (_summary, _stats, cache) = scanner.scan_codex_detailed_with_cache(None);
            if cache.previous_report.is_none() && !cache.codex_scan_incomplete {
                for (day_key, slot) in &mut daily_costs {
                    if cache
                        .scan_since_key
                        .as_deref()
                        .is_some_and(|since| day_key.as_str() >= since)
                        && cache
                            .scan_until_key
                            .as_deref()
                            .is_some_and(|until| day_key.as_str() <= until)
                    {
                        *slot = Some(0.0);
                    }
                }
            }
            for (day_key, models) in &cache.days {
                let Some(slot) = daily_costs.get_mut(day_key) else {
                    continue;
                };
                let Some(day) = CostUsageDayRange::parse_day_key(day_key) else {
                    continue;
                };
                let day_range = CostUsageDayRange::new(day, day);
                let mut one_day = HashMap::new();
                one_day.insert(day_key.clone(), models.clone());
                let mut scratch = CostSummary::default();
                let (cost, _) = add_codex_days_map_to_summary(&mut scratch, &one_day, &day_range);
                *slot = (!scratch.model_pricing_completeness.is_partial()).then_some(cost);
            }
        }
        "claude" => {
            // Real per-day breakdown: walk the project logs once,
            // de-duplicating records across files.
            let roots = scanner.claude_projects_roots();
            if !roots.paths.is_empty() {
                let cutoff = Utc::now() - Duration::days(days as i64);
                let mut seen = HashSet::new();
                let mut pricing = ClaudeScanPricingResolver::default();
                let mut claude_scan = ClaudeFileScanResult::default();
                let mut incomplete = ClaudeIncompleteTracker::default();
                let mut unknown_cost_dates = HashSet::new();
                let traversal_read_failures = {
                    let mut handle_file = |path: &Path| {
                        let mut aggregation_complete = true;
                        let mut file_result = scan_claude_file_with_pricing(
                            path,
                            &cutoff,
                            &mut seen,
                            None,
                            &mut pricing,
                            &mut incomplete,
                            |record| {
                                aggregation_complete &= record.timestamp.is_some();
                                aggregation_complete &= add_claude_record_to_daily_costs(
                                    &mut daily_costs,
                                    &mut unknown_cost_dates,
                                    record,
                                );
                            },
                        );
                        if !aggregation_complete {
                            file_result.aggregation_failures =
                                file_result.aggregation_failures.saturating_add(1);
                        }
                        claude_scan.absorb(file_result);
                    };
                    scanner.walk_claude_roots(&roots.paths, &cutoff, None, &mut handle_file)
                };
                claude_scan.read_failures = claude_scan
                    .read_failures
                    .saturating_add(roots.read_failures)
                    .saturating_add(traversal_read_failures);
                daily_incomplete = incomplete.resolve(&seen).daily_sorted();
                if claude_scan.is_complete() {
                    zero_fill_uninitialized_claude_daily_costs(
                        &mut daily_costs,
                        &unknown_cost_dates,
                    );
                }
            }
        }
        "opencodego" => {
            // Per-day cost from the local OpenCode SQLite reader (upstream #2649).
            // Rows are grouped by local calendar day to match Codex/Claude keying.
            for (day_key, cost) in opencodego_local::daily_cost_series(Utc::now(), days) {
                if let Some(slot) = daily_costs.get_mut(&day_key) {
                    *slot = Some(slot.unwrap_or(0.0) + cost);
                }
            }
        }
        "pi" => {
            let scan = crate::pi_session_cost::scan_pi_daily(days, None);
            for (day_key, cost) in &scan.costs {
                if let Some(slot) = daily_costs.get_mut(day_key) {
                    *slot = (!scan.unpriced_days.contains(day_key)).then_some(*cost);
                }
            }
            if scan.history_coverage_established {
                for (day_key, slot) in &mut daily_costs {
                    if slot.is_none() && !scan.unpriced_days.contains(day_key) {
                        *slot = Some(0.0);
                    }
                }
            }
        }
        _ => {}
    }

    // Convert to sorted vector
    let mut result: Vec<(String, Option<f64>)> = daily_costs.into_iter().collect();
    result.sort_by(|a, b| a.0.cmp(&b.0));
    (result, daily_incomplete)
}

/// Daily token totals (provider-aware, see [`cache_is_separate_from_input`])
/// for the Tokens chart mode, plus
/// whether local history looks incomplete at the old edge of the window
/// (Codex backfill still in progress → the chart shows a "Refreshing"
/// marker; upstream 0.50.0 #2930).
pub fn get_daily_token_history(provider: &str, days: u32) -> (Vec<(String, u64)>, bool) {
    let scanner = CostScanner::new(days);
    let today = cost_bucket_zone().date(Utc::now());
    let mut daily_tokens: HashMap<String, u64> = HashMap::new();
    let mut covered_days: HashSet<String> = HashSet::new();

    // Initialize all days with 0
    for days_ago in 0..days {
        let date = today - Duration::days(days_ago as i64);
        let date_str = date.format("%Y-%m-%d").to_string();
        daily_tokens.insert(date_str, 0);
    }

    match provider {
        "codex" => {
            // Warm/refresh the disk cache, then read exact local token totals
            // from packed days through the same summary path the cost chart
            // uses.
            let (_summary, _stats, cache) = scanner.scan_codex_detailed_with_cache(None);
            for (day_key, models) in &cache.days {
                if !daily_tokens.contains_key(day_key) {
                    continue;
                }
                let Some(day) = CostUsageDayRange::parse_day_key(day_key) else {
                    continue;
                };
                let day_range = CostUsageDayRange::new(day, day);
                let mut one_day = HashMap::new();
                one_day.insert(day_key.clone(), models.clone());
                let mut scratch = CostSummary::default();
                add_codex_days_map_to_summary(&mut scratch, &one_day, &day_range);
                if let Some(slot) = daily_tokens.get_mut(day_key) {
                    *slot = scratch.total_tokens_for_provider("codex");
                }
                covered_days.insert(day_key.clone());
            }
        }
        "claude" => {
            // Per-day token breakdown from the same de-duplicated record walk
            // as the cost chart. Only a complete valid walk establishes
            // authoritative coverage of the requested history window.
            let roots = scanner.claude_projects_roots();
            if !roots.paths.is_empty() {
                let cutoff = Utc::now() - Duration::days(days as i64);
                let mut seen = HashSet::new();
                let mut pricing = ClaudeScanPricingResolver::default();
                let mut claude_scan = ClaudeFileScanResult::default();
                let traversal_read_failures = {
                    let mut handle_file = |path: &Path| {
                        let file_result = scan_claude_file_for_daily_tokens(
                            path,
                            &cutoff,
                            &mut seen,
                            &mut pricing,
                            &mut daily_tokens,
                        );
                        claude_scan.absorb(file_result);
                    };
                    scanner.walk_claude_roots(&roots.paths, &cutoff, None, &mut handle_file)
                };
                claude_scan.read_failures = claude_scan
                    .read_failures
                    .saturating_add(roots.read_failures)
                    .saturating_add(traversal_read_failures);
                mark_claude_daily_token_coverage(&mut covered_days, &daily_tokens, claude_scan);
            }
        }
        "pi" => {
            let scan = crate::pi_session_cost::scan_pi_daily(days, None);
            for (day_key, tokens) in scan.tokens {
                if let Some(slot) = daily_tokens.get_mut(&day_key) {
                    *slot = tokens;
                }
            }
            if scan.history_coverage_established {
                covered_days.extend(daily_tokens.keys().cloned());
            }
        }
        _ => {}
    }

    // Convert to sorted vector
    let mut result: Vec<(String, u64)> = daily_tokens.into_iter().collect();
    result.sort_by(|a, b| a.0.cmp(&b.0));

    let incomplete = if matches!(provider, "claude" | "pi") {
        // A complete filesystem scan covers the requested window even when
        // the roots contain no sessions; failed scans leave coverage empty.
        covered_days.is_empty()
    } else {
        // Codex catch-up may not have reached the oldest quarter of the window.
        provider == "codex"
            && !covered_days.is_empty()
            && covered_days.len() < days as usize
            && result[..(result.len() / 4).max(1)]
                .iter()
                .any(|(date, _)| !covered_days.contains(date))
    };

    (result, incomplete)
}

fn add_claude_record_to_daily_tokens(
    daily_tokens: &mut HashMap<String, u64>,
    record: &ClaudeUsageRecord,
) -> bool {
    let Some(timestamp) = record.timestamp else {
        return true;
    };
    let date_str = cost_bucket_zone()
        .date(timestamp)
        .format("%Y-%m-%d")
        .to_string();
    if let Some(slot) = daily_tokens.get_mut(&date_str) {
        // Claude reports cache reads and writes separately from input, so the
        // day total includes them (same rule as the window and model totals).
        let Some(tokens) = record
            .input
            .checked_add(record.output)
            .and_then(|tokens| tokens.checked_add(record.cache_read))
            .and_then(|tokens| tokens.checked_add(record.cache_create))
        else {
            return false;
        };
        return checked_add_assign(slot, tokens);
    }
    true
}

fn scan_claude_file_for_daily_tokens(
    path: &Path,
    cutoff: &DateTime<Utc>,
    seen: &mut HashSet<ClaudeUsageDedupKey>,
    pricing: &mut ClaudeScanPricingResolver,
    daily_tokens: &mut HashMap<String, u64>,
) -> ClaudeFileScanResult {
    let mut aggregation_failures = 0u32;
    // Token history ignores incomplete-request markers.
    let mut incomplete = ClaudeIncompleteTracker::default();
    let mut result = scan_claude_file_with_pricing(
        path,
        cutoff,
        seen,
        None,
        pricing,
        &mut incomplete,
        |record| {
            if record.timestamp.is_none()
                || !add_claude_record_to_daily_tokens(daily_tokens, record)
            {
                aggregation_failures = aggregation_failures.saturating_add(1);
            }
        },
    );
    result.aggregation_failures = result
        .aggregation_failures
        .saturating_add(aggregation_failures);
    result
}

fn mark_claude_daily_token_coverage(
    covered_days: &mut HashSet<String>,
    daily_tokens: &HashMap<String, u64>,
    scan_result: ClaudeFileScanResult,
) {
    if scan_result.is_complete() {
        covered_days.extend(daily_tokens.keys().cloned());
    } else {
        covered_days.clear();
    }
}
