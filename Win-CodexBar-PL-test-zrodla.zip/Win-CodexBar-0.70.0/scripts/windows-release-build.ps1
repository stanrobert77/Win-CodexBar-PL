#Requires -Version 5.1
<#
.SYNOPSIS
    Build Windows release artifacts with persistent caches.

.DESCRIPTION
    Creates or updates a clean managed checkout for the requested Git ref, builds
    the Tauri desktop release binary with pnpm and Cargo caches outside the
    source tree, packages the Inno Setup installer, and emits the same release
    assets used by GitHub Releases.

    This is intended for the Windows build server path. It preserves expensive
    build caches between releases without reusing a dirty source checkout.

.PARAMETER Ref
    Git ref to build. Use a tag such as v0.27.4 for release artifacts.

.PARAMETER RepoUrl
    Git repository URL used when the managed checkout does not exist.

.PARAMETER WorkRoot
    Root directory for the managed source checkout, cache, and output assets.

.PARAMETER RefreshInstallerDependencies
    Re-download WebView2 and VC++ bootstrapper files instead of reusing the
    signed cached copies.

.PARAMETER WarmCacheOnly
    Build the desktop binary and stop before installer packaging. Use this to
    warm the Windows Cargo and pnpm caches after a large port.
.PARAMETER SmokeInstall
    After packaging, run scripts/windows-smoke-install.ps1 against the generated
    installer and uninstall it again.


.EXAMPLE
    .\scripts\windows-release-build.ps1 -Ref v0.27.4

#>

param(
    [string]$Ref = "HEAD",
    [string]$RepoUrl = "https://github.com/nesszer/Win-CodexBar.git",
    [string]$WorkRoot = "C:\code\Win-CodexBar-release",
    [switch]$RefreshInstallerDependencies,
    [switch]$WarmCacheOnly,
    [switch]$SmokeInstall
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$env:CARGO_TERM_COLOR = "never"
$env:CARGO_TERM_PROGRESS_WHEN = "never"
$env:NO_COLOR = "1"
trap {
    Write-Host $_
    [Environment]::Exit(1)
}

$SourceDir = Join-Path $WorkRoot "source"
$CacheDir = Join-Path $WorkRoot "cache"
$PnpmStoreDir = Join-Path $CacheDir "pnpm-store"
$InstallerDepsDir = Join-Path $CacheDir "installer-deps"
$AssetsDir = Join-Path $WorkRoot "assets"
$DesktopCargoTargetDir = Join-Path $CacheDir "cargo-target"
$CliCargoTargetDir = Join-Path $CacheDir "cargo-target-cli"

function Add-PathIfPresent {
    param([AllowNull()][string]$Path)

    if ([string]::IsNullOrWhiteSpace($Path) -or -not (Test-Path -LiteralPath $Path -PathType Container)) {
        return
    }
    if (@($env:Path -split ';') -notcontains $Path) {
        $env:Path = "$Path;$env:Path"
    }
}

$UserCargoBin = Join-Path $env:USERPROFILE ".cargo\bin"
Add-PathIfPresent $UserCargoBin
foreach ($nodeRoot in @($env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:LOCALAPPDATA)) {
    if (-not [string]::IsNullOrWhiteSpace($nodeRoot)) {
        Add-PathIfPresent (Join-Path $nodeRoot 'nodejs')
    }
}
if ($env:APPDATA) { Add-PathIfPresent (Join-Path $env:APPDATA 'npm') }
if ($env:LOCALAPPDATA) { Add-PathIfPresent (Join-Path $env:LOCALAPPDATA 'pnpm') }
if ($env:LOCALAPPDATA) { Add-PathIfPresent (Join-Path $env:LOCALAPPDATA 'CodexBar\release-toolchain\pnpm') }

function Require-Command {
    param([string]$Name)

    $command = Get-Command $Name -ErrorAction SilentlyContinue
    if (-not $command) {
        throw "Missing required command: $Name"
    }
    return $command
}

function Invoke-Native {
    param(
        [string]$FilePath,
        [string[]]$ArgumentList
    )

    $previousErrorActionPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        & $FilePath @ArgumentList 2>&1 | ForEach-Object { Write-Host $_ }
        $nativeExitCode = $LASTEXITCODE
    } finally {
        $ErrorActionPreference = $previousErrorActionPreference
    }
    if ($nativeExitCode -ne 0) {
        throw "$FilePath exited with code $nativeExitCode"
    }
}

function Get-AppVersion {
    param([string]$CargoTomlPath)

    $line = Get-Content $CargoTomlPath | Where-Object { $_ -match '^version = "([^"]+)"' } | Select-Object -First 1
    if (-not $line -or $line -notmatch '^version = "([^"]+)"') {
        throw "Failed to determine app version from $CargoTomlPath"
    }
    return $Matches[1]
}

function Assert-MicrosoftSignature {
    param([string]$Path)

    if (-not (Test-Path $Path)) {
        throw "Missing installer dependency: $Path"
    }

    $signature = Get-AuthenticodeSignature -FilePath $Path
    if ($signature.Status -ne "Valid") {
        throw "$Path signature is not valid. Status: $($signature.Status)"
    }

    $subject = $signature.SignerCertificate.Subject
    if ($subject -notlike "*Microsoft Corporation*") {
        throw "$Path signer is unexpected: $subject"
    }
}

function Get-InnoSetupCompiler {
    $candidates = @(
        (Join-Path ${env:ProgramFiles(x86)} "Inno Setup 6\ISCC.exe"),
        (Join-Path $env:ProgramFiles "Inno Setup 6\ISCC.exe"),
        (Join-Path $env:LOCALAPPDATA "Programs\Inno Setup 6\ISCC.exe")
    )

    foreach ($candidate in $candidates) {
        if ($candidate -and (Test-Path $candidate)) {
            return $candidate
        }
    }

    $command = Get-Command "ISCC.exe" -ErrorAction SilentlyContinue
    if ($command) {
        return $command.Source
    }

    throw "Inno Setup compiler not found. Install JRSoftware.InnoSetup with winget or Inno Setup 6 from jrsoftware.org."
}

function Invoke-DownloadWithRetry {
    param(
        [string]$Uri,
        [string]$OutFile,
        [int]$Attempts = 3
    )

    for ($attempt = 1; $attempt -le $Attempts; $attempt++) {
        try {
            Write-Host "Downloading $Uri (attempt $attempt/$Attempts)"
            Invoke-WebRequest -Uri $Uri -OutFile $OutFile
            return
        } catch {
            if ($attempt -eq $Attempts) {
                throw
            }
            Write-Host "Download failed: $($_.Exception.Message)"
            Start-Sleep -Seconds (5 * $attempt)
        }
    }
}

function Get-ObjdumpImportsWebView2Loader {
    param([string]$ExePath)

    $objdump = Get-Command objdump -ErrorAction SilentlyContinue
    if (-not $objdump) {
        return $false
    }

    $output = & $objdump.Source -p $ExePath
    return [bool]($output | Select-String -Pattern "DLL Name: WebView2Loader.dll" -Quiet)
}

$git = Require-Command "git"
$rustupBinCandidates = @()
if ($env:CARGO_HOME) {
    $rustupBinCandidates += Join-Path $env:CARGO_HOME 'bin'
}
if ($env:USERPROFILE) {
    $rustupBinCandidates += Join-Path $env:USERPROFILE '.cargo\bin'
}
foreach ($rustupBinDir in $rustupBinCandidates) {
    if ((Test-Path -LiteralPath $rustupBinDir -PathType Container) -and (@($env:Path -split ';') -notcontains $rustupBinDir)) {
        $env:Path = "$rustupBinDir;$env:Path"
    }
}
$rustup = Get-Command rustup -ErrorAction SilentlyContinue
if (-not $rustup) {
    throw 'rustup is required for Windows release builds.'
}
$previousErrorActionPreference = $ErrorActionPreference
try {
    $ErrorActionPreference = 'Continue'
    & $rustup.Source set auto-self-update disable 2>&1 | ForEach-Object { Write-Host $_ }
    $rustupExitCode = $LASTEXITCODE
} finally {
    $ErrorActionPreference = $previousErrorActionPreference
}
if ($rustupExitCode -ne 0) {
    Write-Host "Warning: rustup auto-self-update disable failed with exit code $rustupExitCode"
}
$toolchain = 'stable-x86_64-pc-windows-msvc'
$target = if ($env:CARGO_BUILD_TARGET) { $env:CARGO_BUILD_TARGET } else { 'x86_64-pc-windows-msvc' }
Invoke-Native $rustup.Source @('toolchain', 'install', $toolchain, '--profile', 'default')
$previousErrorActionPreference = $ErrorActionPreference
try {
    $ErrorActionPreference = 'Continue'
    & $rustup.Source target add $target --toolchain $toolchain 2>&1 | ForEach-Object { Write-Host $_ }
    $rustupExitCode = $LASTEXITCODE
} finally {
    $ErrorActionPreference = $previousErrorActionPreference
}
if ($rustupExitCode -ne 0) {
    throw "$($rustup.Source) target add $target --toolchain $toolchain exited with code $rustupExitCode"
}
$env:RUSTUP_TOOLCHAIN = $toolchain
$rustupBinDir = Split-Path -Parent $rustup.Source
foreach ($proxy in @('cargo', 'rustc', 'rustfmt', 'clippy-driver', 'rls', 'rust-analyzer')) {
    $proxyPath = Join-Path $rustupBinDir "$proxy.exe"
    if (-not (Test-Path -LiteralPath $proxyPath)) {
        Copy-Item -LiteralPath $rustup.Source -Destination $proxyPath -Force
        Write-Host "Created rustup proxy: $proxyPath"
    }
}
$env:Path = "$rustupBinDir;$env:Path"
$cargo = Get-Command cargo -ErrorAction Stop
$rustcCmd = Get-Command rustc -ErrorAction Stop
$pnpm = Require-Command "pnpm"
Write-Host "Rustup command: $($rustup.Source)"
Write-Host "Cargo command: $($cargo.Source)"
Write-Host "Rustc command: $($rustcCmd.Source)"

New-Item -ItemType Directory -Force $WorkRoot, $CacheDir, $DesktopCargoTargetDir, $CliCargoTargetDir, $PnpmStoreDir, $InstallerDepsDir, $AssetsDir | Out-Null

if (-not (Test-Path (Join-Path $SourceDir ".git"))) {
    if (Test-Path $SourceDir) {
        throw "$SourceDir exists but is not a Git checkout. Move it aside or choose another WorkRoot."
    }
    Invoke-Native $git.Source @("clone", "--quiet", $RepoUrl, $SourceDir)
}

Push-Location $SourceDir
try {
    Invoke-Native $git.Source @("fetch", "--quiet", "--tags", "--prune", "origin")
    Invoke-Native $git.Source @("-c", "advice.detachedHead=false", "checkout", "--quiet", "--force", $Ref)
    Invoke-Native $git.Source @("reset", "--quiet", "--hard", "HEAD")
    Invoke-Native $git.Source @("clean", "-ffdq", "-e", "apps/desktop-tauri/node_modules/")

    $commit = (& $git.Source rev-parse HEAD).Trim()
    $version = Get-AppVersion -CargoTomlPath (Join-Path $SourceDir "rust\Cargo.toml")

    $env:APP_VERSION = $version
    $env:CARGO_TARGET_DIR = $DesktopCargoTargetDir
    if (-not $env:CARGO_BUILD_TARGET -and [System.Runtime.InteropServices.RuntimeInformation]::IsOSPlatform(
        [System.Runtime.InteropServices.OSPlatform]::Windows
    )) {
        $env:CARGO_BUILD_TARGET = "x86_64-pc-windows-msvc"
    }
    if ($env:CARGO_BUILD_TARGET -and $rustup) {
        $installedRustTargets = @(& $rustup.Source target list --installed --toolchain $toolchain)
        Write-Host "Rust installed targets ($toolchain): $($installedRustTargets -join ', ')"
    }
    $env:PNPM_HOME = if ($env:PNPM_HOME) { $env:PNPM_HOME } else { Join-Path $CacheDir "pnpm-home" }

    Write-Host "Building Win-CodexBar $version from $commit"
    Write-Host "Source: $SourceDir"
    Write-Host "Cargo target cache: $DesktopCargoTargetDir"
    Write-Host "pnpm store cache: $PnpmStoreDir"

    Invoke-Native $pnpm.Source @(
        "--dir", "apps\desktop-tauri",
        "install",
        "--frozen-lockfile",
        "--store-dir", $PnpmStoreDir
    )

    $tauriBuildLog = Join-Path $AssetsDir "tauri-build.log"
    $tauriBuildErrLog = Join-Path $AssetsDir "tauri-build.err.log"
    Write-Host "Running Tauri build. Logs: $tauriBuildLog and $tauriBuildErrLog"
    $tauriBuildArgs = @(
        "--dir",
        "apps\desktop-tauri",
        "exec",
        "tauri",
        "build",
        "--ci",
        "--no-bundle"
    )
    if ($env:CARGO_BUILD_TARGET) {
        $tauriBuildArgs += @("--target", $env:CARGO_BUILD_TARGET)
    }
    $tauriBuildArgs += @("--", "--quiet")
    $quotedArgs = $tauriBuildArgs | ForEach-Object {
        if ($_ -match '[\s"]') {
            '"' + ($_ -replace '"', '\"') + '"'
        } else {
            $_
        }
    }
    $commandLine = "pnpm " + ($quotedArgs -join " ")
    $process = Start-Process -FilePath "cmd.exe" `
        -ArgumentList @("/d", "/s", "/c", $commandLine) `
        -NoNewWindow `
        -PassThru `
        -RedirectStandardOutput $tauriBuildLog `
        -RedirectStandardError $tauriBuildErrLog
    while (-not $process.HasExited) {
        Start-Sleep -Seconds 30
        Write-Host "Tauri build still running..."
        $process.Refresh()
    }
    $process.WaitForExit()
    $process.Refresh()
    $releaseBinDir = if ($env:CARGO_BUILD_TARGET) {
        Join-Path $DesktopCargoTargetDir "$($env:CARGO_BUILD_TARGET)\release"
    } else {
        Join-Path $DesktopCargoTargetDir "release"
    }
    $sourceExe = Join-Path $releaseBinDir "codexbar-desktop-tauri.exe"
    if ($null -eq $process.ExitCode) {
        if (Test-Path $sourceExe) {
            Write-Host "Warning: Tauri build did not report an exit code, but produced $sourceExe."
        } else {
            Write-Host "Tauri build did not report an exit code. Last 200 stdout lines:"
            if (Test-Path $tauriBuildLog) {
                Get-Content $tauriBuildLog -Tail 200
            }
            Write-Host "Last 200 stderr lines:"
            if (Test-Path $tauriBuildErrLog) {
                Get-Content $tauriBuildErrLog -Tail 200
            }
            throw "pnpm tauri build completed without a reliable exit code"
        }
    }
    $tauriExitCode = if ($null -eq $process.ExitCode) { 0 } else { $process.ExitCode }
    if ($tauriExitCode -ne 0) {
        Write-Host "Tauri build failed with exit code $tauriExitCode. Last 200 stdout lines:"
        if (Test-Path $tauriBuildLog) {
            Get-Content $tauriBuildLog -Tail 200
        }
        Write-Host "Last 200 stderr lines:"
        if (Test-Path $tauriBuildErrLog) {
            Get-Content $tauriBuildErrLog -Tail 200
        }
        throw "pnpm tauri build exited with code $tauriExitCode"
    }

    $desktopExe = Join-Path $releaseBinDir "codexbar.exe"
    $legacyDesktopExe = Join-Path $releaseBinDir "codexbar-desktop.exe"
    $releaseExe = Join-Path $releaseBinDir "codexbar-cli.exe"
    if (-not (Test-Path $sourceExe)) {
        throw "Missing expected Tauri binary: $sourceExe"
    }

    Copy-Item $sourceExe $desktopExe -Force
    Copy-Item $sourceExe $legacyDesktopExe -Force
    if (Get-ObjdumpImportsWebView2Loader -ExePath $desktopExe) {
        throw "codexbar.exe imports WebView2Loader.dll, but release builds are expected to statically link the loader."
    }

    $env:CARGO_TARGET_DIR = $CliCargoTargetDir
    Write-Host "Building CLI binary"
    Write-Host "CLI Cargo target cache: $CliCargoTargetDir"
    Invoke-Native $cargo.Source @(
        "build",
        "--manifest-path", "rust\Cargo.toml",
        "--release",
        "--bin", "codexbar"
    )
    $env:CARGO_TARGET_DIR = $DesktopCargoTargetDir

    $cliBinDir = if ($env:CARGO_BUILD_TARGET) {
        Join-Path $CliCargoTargetDir "$($env:CARGO_BUILD_TARGET)\release"
    } else {
        Join-Path $CliCargoTargetDir "release"
    }
    $sourceCliExe = Join-Path $cliBinDir "codexbar.exe"
    if (-not (Test-Path $sourceCliExe)) {
        throw "Missing expected CLI binary: $sourceCliExe"
    }
    Copy-Item $sourceCliExe $releaseExe -Force

    $verifyExecutablesScript = Join-Path $SourceDir "scripts\verify-windows-executables.ps1"
    if (-not (Test-Path $verifyExecutablesScript)) {
        throw "Executable verification script not found: $verifyExecutablesScript"
    }
    & $verifyExecutablesScript `
        -DesktopExe $desktopExe `
        -CliExe $releaseExe `
        -LegacyDesktopExe $legacyDesktopExe `
        -CheckCliStdout

    if ($WarmCacheOnly) {
        $warmExe = Join-Path $AssetsDir "CodexBar-$version-warm.exe"
        Copy-Item $desktopExe $warmExe -Force
        Write-Host ""
        Write-Host "Warm build artifact: $warmExe"
        Write-Host "Warm cache completed. Skipping installer packaging because -WarmCacheOnly was supplied."
        return
    }

    $vcRedistPath = Join-Path $InstallerDepsDir "vc_redist.x64.exe"
    $webView2BootstrapperPath = Join-Path $InstallerDepsDir "MicrosoftEdgeWebview2Setup.exe"

    if ($RefreshInstallerDependencies -or -not (Test-Path $vcRedistPath)) {
        Invoke-DownloadWithRetry -Uri "https://aka.ms/vc14/vc_redist.x64.exe" -OutFile $vcRedistPath
    }
    if ($RefreshInstallerDependencies -or -not (Test-Path $webView2BootstrapperPath)) {
        Invoke-DownloadWithRetry -Uri "https://go.microsoft.com/fwlink/p/?LinkId=2124703" -OutFile $webView2BootstrapperPath
    }

    Assert-MicrosoftSignature -Path $vcRedistPath
    Assert-MicrosoftSignature -Path $webView2BootstrapperPath

    $iscc = Get-InnoSetupCompiler

    $installerOut = Join-Path $CacheDir "installer"
    New-Item -ItemType Directory -Force $installerOut | Out-Null

    Push-Location "rust\installer"
    try {
        Invoke-Native $iscc @(
            "/Qp",
            "/DAppVersion=$version",
            "/DTargetBinDir=$releaseBinDir",
            "/DVCRedistPath=$vcRedistPath",
            "/DWebView2BootstrapperPath=$webView2BootstrapperPath",
            "/DOutputDir=$installerOut",
            "/DOutputBaseFilename=CodexBar-$version-Setup",
            "codexbar.iss"
        )
    } finally {
        Pop-Location
    }

    $installer = Join-Path $installerOut "CodexBar-$version-Setup.exe"
    $portableExe = Join-Path $AssetsDir "CodexBar-$version-portable.exe"
    $installerAsset = Join-Path $AssetsDir "CodexBar-$version-Setup.exe"
    $cliZip = Join-Path $AssetsDir "CodexBarCLI-v$version-windows-x64.zip"

    foreach ($path in @($desktopExe, $releaseExe, $installer)) {
        if (-not (Test-Path $path)) {
            throw "Missing expected asset: $path"
        }
    }

    Copy-Item $desktopExe $portableExe -Force
    Copy-Item $installer $installerAsset -Force
    Compress-Archive -Path $releaseExe -DestinationPath $cliZip -Force

    $zipVerifyDir = Join-Path ([IO.Path]::GetTempPath()) ("codexbar-cli-zip-verify-" + [guid]::NewGuid().ToString('N'))
    Expand-Archive -LiteralPath $cliZip -DestinationPath $zipVerifyDir -Force
    $extractedCli = Join-Path $zipVerifyDir "codexbar-cli.exe"
    if (-not (Test-Path -LiteralPath $extractedCli -PathType Leaf)) { throw "CLI zip missing codexbar-cli.exe entry: $cliZip" }
    if ((Get-FileHash -LiteralPath $extractedCli -Algorithm SHA256).Hash -cne (Get-FileHash -LiteralPath $releaseExe -Algorithm SHA256).Hash) { throw "CLI zip entry hash mismatch: $cliZip" }

    foreach ($asset in @($installerAsset, $portableExe, $cliZip)) {
        $fileName = Split-Path $asset -Leaf
        $hash = (Get-FileHash -Algorithm SHA256 $asset).Hash.ToLower()
        "$hash  $fileName" | Set-Content -Encoding ascii "$asset.sha256"
    }

    if ($SmokeInstall) {
        $smokeScript = Join-Path $SourceDir "scripts\windows-smoke-install.ps1"
        if (-not (Test-Path $smokeScript)) {
            throw "Smoke install script not found: $smokeScript"
        }
        & $smokeScript -InstallerPath $installerAsset -ExpectedVersion $version
        if ($LASTEXITCODE -ne 0) {
            throw "Smoke install failed with exit code $LASTEXITCODE"
        }
    }


    Write-Host ""
    Write-Host "Release assets:"
    Get-ChildItem $AssetsDir -Filter "CodexBar*" |
        Sort-Object Name |
        Select-Object Name, Length, LastWriteTime |
        Format-Table -AutoSize
} finally {
    Pop-Location
}
